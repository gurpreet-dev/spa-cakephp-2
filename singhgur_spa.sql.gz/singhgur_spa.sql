-- MySQL dump 10.13  Distrib 5.6.38, for Linux (x86_64)
--
-- Host: localhost    Database: singhgur_spa
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_contacts`
--

DROP TABLE IF EXISTS `admin_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_contacts`
--

LOCK TABLES `admin_contacts` WRITE;
/*!40000 ALTER TABLE `admin_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sessionid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(11) unsigned DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` decimal(6,2) DEFAULT NULL,
  `price` decimal(6,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight_total` decimal(6,2) DEFAULT NULL,
  `subtotal` decimal(6,2) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` (`id`, `sessionid`, `product_id`, `uid`, `store_id`, `name`, `weight`, `price`, `quantity`, `image`, `weight_total`, `subtotal`, `created`, `modified`) VALUES (3,'cdb5cccc6cae132e9bcdc5e32a747232',57,43,6,'Angove Long Row Chardonnay (2016)',250.00,45.00,6,'angove-long-row1.png',1500.00,270.00,'2017-05-03 10:19:51','2017-05-03 10:19:51'),(4,'cdb5cccc6cae132e9bcdc5e32a747232',68,43,1,'Lunardi Soave',500.00,70.00,1,'W5755_670.png',500.00,70.00,'2017-05-03 11:01:30','2017-05-03 11:01:30'),(5,'cdb5cccc6cae132e9bcdc5e32a747232',70,43,1,'Billaud-Simon Chablis 2015 ',750.00,45.00,1,'ci_3756.jpg',750.00,45.00,'2017-05-03 11:09:31','2017-05-03 11:09:31'),(6,'cdb5cccc6cae132e9bcdc5e32a747232',73,43,1,'Oliver Soft White',500.00,300.00,1,'whitewine 1.png',500.00,300.00,'2017-05-03 11:12:29','2017-05-03 11:12:29'),(8,'cdb5cccc6cae132e9bcdc5e32a747232',64,43,1,'Wooing Tree Pinot Noir Rose (2014) - 375mL',375.00,8.00,1,'wooing_tree_pinot_noir_rose_2014_375mL.jpg',375.00,8.00,'2017-05-03 12:09:10','2017-05-03 12:09:10'),(9,'cdb5cccc6cae132e9bcdc5e32a747232',80,43,1,'Dandelion Legacy Of The Barossa Pedro Ximenez',750.00,145.00,1,'desrt.png',750.00,145.00,'2017-05-03 12:47:58','2017-05-03 12:47:58'),(10,'cdb5cccc6cae132e9bcdc5e32a747232',76,43,1,'Ayrum',750.00,100.00,1,'airum-rosado.png',750.00,100.00,'2017-05-03 12:49:20','2017-05-03 12:49:20');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rght` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `parent_id`, `user_id`, `lft`, `rght`, `name`, `slug`, `image`, `description`, `status`, `created`, `modified`) VALUES (2,NULL,43,1,2,'Hair styling2','hair-styling','174650service2.jpg','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',0,'2017-05-16 06:18:34','2018-03-09 10:32:48'),(3,NULL,43,3,4,'Hair cut','hair-cut','1857217.jpg','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',0,'2017-05-16 06:18:54','2017-06-28 18:58:52'),(4,NULL,43,5,6,'Eye lash','eye-lash','174709service3.jpg','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',1,'2017-05-16 06:19:19','2018-03-07 16:27:21'),(5,NULL,43,7,8,'Body Massage','body-massage','1857393.jpg','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',0,'2017-05-16 06:19:46','2017-06-28 18:57:39'),(6,NULL,43,9,10,'Waxing','waxing','19015417.jpg','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',0,'2017-05-16 06:20:03','2017-06-28 19:01:54'),(7,NULL,43,11,12,'Beard','beard',NULL,'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',1,'2017-05-16 06:20:18','2018-03-08 18:18:44'),(8,NULL,43,13,14,'Massage','massage','174735massage.jpg','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).',1,'2017-06-21 19:18:15','2017-06-27 16:42:12');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `feedback` text NOT NULL,
  `reply` text,
  `answered` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `feedback`, `reply`, `answered`, `created`, `modified`) VALUES (1,'Gurpreet singh','gurpreet@avainfotech.com','9999955555','test','egfwesgewsg',1,'2017-06-15 16:52:16','2017-06-24 17:38:30'),(2,'Diksha','diksha@avainfotech.com','123456789','I want to know from where have you developed this website, it looks amazing!!!!!',NULL,0,'2017-06-15 18:35:14','2017-06-15 18:35:14'),(3,'Diksha','diksha@avainfotech.com','9780099887',' Lorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem Ipsum','Ok. I will be in contact',1,'2017-06-26 13:27:00','2017-08-24 11:07:22'),(4,'54656564556','diksha@avainfotech.com','56456',' LoremipsumLoremipsumLoremipsumLoremipsumLoremipsumLoremipsumLoremipsumLoremipsumLoremipsum','8uolol',1,'2017-06-26 13:30:42','2017-06-28 17:47:14'),(5,'Gurpreet singh','gurpreet@avainfotech.com','1234567891','tyreyhryr',NULL,0,'2017-09-28 11:18:31','2017-09-28 11:18:31'),(6,'Gurpreet singh','gurpreet@avainfotech.com','1234567891','dydrutyitiityityityit',NULL,0,'2017-09-28 15:33:04','2017-09-28 15:33:04'),(7,'vandana','kavita20@gmail.com','0000000000','good','gdhgegf',1,'2018-02-19 13:14:54','2018-02-19 15:29:33'),(8,'!!!!@@@@@########','email@cart.com','8556075698','hello',NULL,0,'2018-03-06 16:02:06','2018-03-06 16:02:06'),(9,'reema','king@g.com','584444444444444444444444444444444444','hello',NULL,0,'2018-03-06 16:07:09','2018-03-06 16:07:09'),(10,'pratee','prateek@avainfotech.com','85858585','good',NULL,0,'2018-03-12 10:04:44','2018-03-12 10:04:44');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(355) DEFAULT NULL,
  `description` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` (`id`, `title`, `description`, `created`, `modified`) VALUES (2,'General Information','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.','2017-06-28 16:38:58','2017-06-28 16:38:58'),(3,'General Information with answer','General Information with answer. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.','2017-06-28 16:40:54','2017-06-28 16:40:54');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` (`id`, `product_id`, `image`, `created`, `modified`) VALUES (1,3,'233940aboutwaer_bg.jpg','2017-03-01 15:09:40','0000-00-00 00:00:00'),(2,3,'233949blog.jpg','2017-03-01 15:09:49','0000-00-00 00:00:00'),(9,27,'icon.png','2017-03-03 20:33:54','0000-00-00 00:00:00'),(10,27,'watch.jpg','2017-03-06 19:23:09','0000-00-00 00:00:00'),(8,27,'mini cooper.JPG','2017-03-03 20:33:39','0000-00-00 00:00:00'),(6,27,'234114media3.jpg','2017-03-01 15:11:14','0000-00-00 00:00:00'),(7,27,'234123blog.jpg','2017-03-01 15:11:24','0000-00-00 00:00:00'),(11,27,'71JT0QUgEYL._UL1500_.jpg','2017-03-06 19:23:50','0000-00-00 00:00:00'),(12,27,'1455902737-watch-junghans-automatic-43.jpg','2017-03-06 19:24:28','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(355) DEFAULT NULL,
  `slug` varchar(355) DEFAULT NULL,
  `link` varchar(355) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` (`id`, `name`, `slug`, `link`, `created`, `modified`) VALUES (1,'IOS','apple','','0000-00-00 00:00:00','2017-07-04 11:48:01'),(2,'Android','android','','0000-00-00 00:00:00','2017-07-04 11:48:10'),(3,'Facebook','facebook','https://facebook.com','0000-00-00 00:00:00','2018-03-08 14:41:39'),(4,'Twitter','twitter','https://twitter.com','0000-00-00 00:00:00','2017-04-10 05:28:25'),(5,'Instagram','instagram','https://instagram.com','0000-00-00 00:00:00','2017-04-10 05:28:40'),(6,'Google Plus','google-plus','https://plus.google.com','0000-00-00 00:00:00','2017-04-10 05:29:01');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `salon_id` int(10) unsigned DEFAULT NULL,
  `service_id` int(11) DEFAULT '0',
  `category` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `price` decimal(8,2) unsigned DEFAULT NULL,
  `time` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` (`id`, `order_id`, `salon_id`, `service_id`, `category`, `name`, `price`, `time`, `created`, `modified`) VALUES (1,1,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-09 15:31:58','2017-06-09 15:31:58'),(2,1,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-09 15:31:58','2017-06-09 15:31:58'),(3,2,168,21,'Hair styling','Hair Massage Extreme',150.00,'200','2017-06-09 15:32:39','2017-06-09 15:32:39'),(4,2,168,20,'Hair styling','Hair Massage Deluxe',200.00,'20','2017-06-09 15:32:39','2017-06-09 15:32:39'),(5,2,168,19,'Hair styling','Hair Spa Deluxe Double',200.00,'80','2017-06-09 15:32:39','2017-06-09 15:32:39'),(6,3,168,15,'Hair color','Hair Spa',150.00,'90','2017-06-09 15:36:58','2017-06-09 15:36:58'),(7,3,168,16,'Hair color','Hair Spa Extreme',300.00,'180','2017-06-09 15:36:58','2017-06-09 15:36:58'),(8,4,151,22,'Beard','Beard wash',25.00,'30','2017-06-09 15:42:44','2017-06-09 15:42:44'),(9,5,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-09 15:59:35','2017-06-09 15:59:35'),(10,6,151,22,'Beard','Beard wash',25.00,'30','2017-06-09 18:10:10','2017-06-09 18:10:10'),(11,7,168,19,'Hair styling','Hair Spa Deluxe Double',200.00,'80','2017-06-10 16:01:19','2017-06-10 16:01:19'),(12,7,168,20,'Hair styling','Hair Massage Deluxe',200.00,'20','2017-06-10 16:01:19','2017-06-10 16:01:19'),(13,7,168,21,'Hair styling','Hair Massage Extreme',150.00,'200','2017-06-10 16:01:19','2017-06-10 16:01:19'),(14,8,168,15,'Hair color','Hair Spa',150.00,'90','2017-06-13 14:58:52','2017-06-13 14:58:52'),(15,8,168,16,'Hair color','Hair Spa Extreme',300.00,'180','2017-06-13 14:58:52','2017-06-13 14:58:52'),(16,9,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-14 15:08:00','2017-06-14 15:08:00'),(17,10,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-14 15:24:54','2017-06-14 15:24:54'),(18,11,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-14 15:41:17','2017-06-14 15:41:17'),(21,13,151,22,'Beard','Beard wash',25.00,'30','2017-06-15 13:15:20','2017-06-15 13:15:20'),(22,14,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-15 15:57:23','2017-06-15 15:57:23'),(23,14,168,18,'Hair styling','Hair Spa Extreme',200.00,'100','2017-06-15 15:57:24','2017-06-15 15:57:24'),(24,15,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-15 18:45:35','2017-06-15 18:45:35'),(25,15,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-15 18:45:35','2017-06-15 18:45:35'),(26,16,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-16 11:24:29','2017-06-16 11:24:29'),(27,17,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-16 13:41:49','2017-06-16 13:41:49'),(28,17,168,18,'Hair styling','Hair Spa Extreme',200.00,'100','2017-06-16 13:41:49','2017-06-16 13:41:49'),(29,17,168,19,'Hair styling','Hair Spa Deluxe Double',200.00,'80','2017-06-16 13:41:49','2017-06-16 13:41:49'),(30,17,168,20,'Hair styling','Hair Massage Deluxe',200.00,'20','2017-06-16 13:41:49','2017-06-16 13:41:49'),(31,18,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-16 13:59:18','2017-06-16 13:59:18'),(32,18,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-16 13:59:18','2017-06-16 13:59:18'),(33,19,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-16 14:01:21','2017-06-16 14:01:21'),(34,19,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-16 14:01:21','2017-06-16 14:01:21'),(35,20,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-16 15:27:29','2017-06-16 15:27:29'),(36,20,168,18,'Hair styling','Hair Spa Extreme',200.00,'100','2017-06-16 15:27:29','2017-06-16 15:27:29'),(37,20,168,19,'Hair styling','Hair Spa Deluxe Double',200.00,'80','2017-06-16 15:27:29','2017-06-16 15:27:29'),(40,22,168,15,'Hair color','Hair Spa',150.00,'90','2017-06-19 19:03:03','2017-06-19 19:03:03'),(41,22,168,16,'Hair color','Hair Spa Extreme',300.00,'180','2017-06-19 19:03:03','2017-06-19 19:03:03'),(43,24,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-20 10:55:58','2017-06-20 10:55:58'),(44,25,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-21 11:37:37','2017-06-21 11:37:37'),(45,25,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-21 11:37:37','2017-06-21 11:37:37'),(46,26,168,15,'Hair color','Hair Spa',150.00,'90','2017-06-21 12:40:21','2017-06-21 12:40:21'),(47,27,151,1,'Hair color','Hair Spa Normal For Men',20.00,'90','2017-06-21 17:26:53','2017-06-21 17:26:53'),(48,27,151,3,'Hair color','Root Touch Up (Inoa) For Women',1200.00,'65','2017-06-21 17:26:53','2017-06-21 17:26:53'),(49,28,168,15,'Hair color','Hair Spa',150.00,'90','2017-06-21 22:08:20','2017-06-21 22:08:20'),(50,29,168,26,'Hair styling','Hair Growth Spa',20.00,'25','2017-06-22 17:24:18','2017-06-22 17:24:18'),(52,31,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-06-23 09:20:11','2017-06-23 09:20:11'),(53,32,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-06-23 09:20:30','2017-06-23 09:20:30'),(54,33,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-06-23 10:59:21','2017-06-23 10:59:21'),(55,34,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-06-24 10:32:03','2017-06-24 10:32:03'),(56,35,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-06-27 10:27:35','2017-06-27 10:27:35'),(57,36,151,22,'Beard','Beard wash',25.00,'30','2017-06-27 15:19:22','2017-06-27 15:19:22'),(58,37,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-06-28 18:12:38','2017-06-28 18:12:38'),(59,37,168,18,'Hair styling','Hair Spa Extreme',200.00,'100','2017-06-28 18:12:38','2017-06-28 18:12:38'),(60,37,168,19,'Hair styling','Hair Spa Deluxe Double',200.00,'80','2017-06-28 18:12:38','2017-06-28 18:12:38'),(61,38,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-07-04 19:57:46','2017-07-04 19:57:46'),(62,39,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-07-04 19:58:10','2017-07-04 19:58:10'),(63,40,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-07-04 19:58:19','2017-07-04 19:58:19'),(64,41,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-07-04 19:58:37','2017-07-04 19:58:37'),(65,42,151,22,'Beard','Beard wash',25.00,'30','2017-09-01 11:32:01','2017-09-01 11:32:01'),(66,43,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-09-08 17:31:52','2017-09-08 17:31:52'),(67,44,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-09-08 17:47:15','2017-09-08 17:47:15'),(68,45,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-09-08 17:55:17','2017-09-08 17:55:17'),(69,46,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-09-08 17:56:51','2017-09-08 17:56:51'),(70,47,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-09-08 17:56:57','2017-09-08 17:56:57'),(71,48,168,17,'Hair styling','Hair Spa Deluxe',200.00,'100','2017-09-08 18:08:05','2017-09-08 18:08:05'),(72,49,168,18,'Hair styling','Hair Spa Extreme',200.00,'100','2017-09-13 12:55:54','2017-09-13 12:55:54'),(73,50,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-09-14 13:45:27','2017-09-14 13:45:27'),(74,51,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-09-14 13:45:53','2017-09-14 13:45:53'),(75,52,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-09-14 13:45:57','2017-09-14 13:45:57'),(76,53,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-09-14 13:45:58','2017-09-14 13:45:58'),(77,54,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-09-14 13:49:02','2017-09-14 13:49:02'),(78,55,151,22,'Beard','Beard wash',25.00,'30','2017-09-27 12:45:44','2017-09-27 12:45:44'),(79,56,151,24,'Eye lash','acc',24.00,'15','2017-09-28 17:03:53','2017-09-28 17:03:53'),(80,57,151,24,'Eye lash','acc',24.00,'15','2017-09-28 17:04:20','2017-09-28 17:04:20'),(81,58,151,22,'Beard','Beard wash',25.00,'30','2017-09-28 17:23:27','2017-09-28 17:23:27'),(82,59,151,32,'Massage','Leg massage',25.00,'10','2017-09-29 11:09:23','2017-09-29 11:09:23'),(83,60,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2017-10-07 12:13:19','2017-10-07 12:13:19'),(84,61,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2017-10-16 20:09:53','2017-10-16 20:09:53'),(85,62,201,33,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',25.00,'40','2017-11-06 13:16:17','2017-11-06 13:16:17'),(86,63,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2017-12-05 14:24:14','2017-12-05 14:24:14'),(87,64,151,22,'Beard','Beard wash',25.00,'30','2017-12-05 14:26:30','2017-12-05 14:26:30'),(88,65,151,32,'Massage','Leg massage',25.00,'10','2017-12-05 17:35:31','2017-12-05 17:35:31'),(89,66,151,22,'Beard','Beard wash',25.00,'30','2017-12-06 12:03:36','2017-12-06 12:03:36'),(90,67,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-01-16 15:09:18','2018-01-16 15:09:18'),(91,68,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-01-16 15:10:18','2018-01-16 15:10:18'),(92,69,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-16 16:28:33','2018-01-16 16:28:33'),(93,70,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-01-18 12:32:30','2018-01-18 12:32:30'),(94,71,168,23,'Eye lash','Eye Massage',100.00,'30','2018-01-18 13:11:02','2018-01-18 13:11:02'),(95,72,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-01-18 13:19:29','2018-01-18 13:19:29'),(96,73,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-18 16:30:07','2018-01-18 16:30:07'),(97,74,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-18 18:27:17','2018-01-18 18:27:17'),(98,75,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-18 18:41:57','2018-01-18 18:41:57'),(99,76,168,23,'Eye lash','Eye Massage',100.00,'30','2018-01-18 18:44:20','2018-01-18 18:44:20'),(100,77,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-19 12:30:43','2018-01-19 12:30:43'),(101,78,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-01-19 14:25:49','2018-01-19 14:25:49'),(102,79,168,23,'Eye lash','Eye Massage',100.00,'30','2018-01-19 15:05:44','2018-01-19 15:05:44'),(103,80,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-01-19 15:32:10','2018-01-19 15:32:10'),(104,81,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-01-19 15:36:34','2018-01-19 15:36:34'),(105,82,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-01-19 17:28:34','2018-01-19 17:28:34'),(106,83,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-19 17:32:30','2018-01-19 17:32:30'),(107,84,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-19 17:35:11','2018-01-19 17:35:11'),(108,85,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-01-19 17:37:47','2018-01-19 17:37:47'),(109,86,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-01-19 17:41:24','2018-01-19 17:41:24'),(110,87,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-19 17:52:00','2018-01-19 17:52:00'),(111,88,168,23,'Eye lash','Eye Massage',100.00,'30','2018-01-19 17:58:01','2018-01-19 17:58:01'),(112,89,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-01-19 18:00:32','2018-01-19 18:00:32'),(113,90,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-01-19 18:03:49','2018-01-19 18:03:49'),(114,91,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-19 18:13:18','2018-01-19 18:13:18'),(115,92,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-19 18:16:54','2018-01-19 18:16:54'),(116,93,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-19 18:33:45','2018-01-19 18:33:45'),(117,94,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-01-19 18:38:47','2018-01-19 18:38:47'),(118,95,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-19 18:50:14','2018-01-19 18:50:14'),(119,96,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-01-19 19:04:02','2018-01-19 19:04:02'),(120,97,168,23,'Eye lash','Eye Massage',100.00,'30','2018-01-23 10:20:45','2018-01-23 10:20:45'),(121,98,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-01-23 10:31:07','2018-01-23 10:31:07'),(122,99,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-01-23 12:51:16','2018-01-23 12:51:16'),(123,100,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-01-23 12:53:32','2018-01-23 12:53:32'),(124,101,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-01-23 13:09:19','2018-01-23 13:09:19'),(125,102,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-01-25 21:52:31','2018-01-25 21:52:31'),(126,103,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-02-01 19:54:51','2018-02-01 19:54:51'),(127,104,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-02-01 19:56:58','2018-02-01 19:56:58'),(128,105,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-02-01 20:06:41','2018-02-01 20:06:41'),(129,106,151,24,'Eye lash','acc',24.00,'15','2018-02-01 20:25:19','2018-02-01 20:25:19'),(130,107,151,24,'Eye lash','acc',24.00,'15','2018-02-01 20:25:33','2018-02-01 20:25:33'),(131,108,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-02-02 13:09:21','2018-02-02 13:09:21'),(132,109,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2018-02-02 13:15:15','2018-02-02 13:15:15'),(133,110,151,22,'Beard','Beard wash',25.00,'30','2018-02-02 13:24:26','2018-02-02 13:24:26'),(134,111,151,32,'Massage','Leg massage',25.00,'10','2018-02-19 12:27:55','2018-02-19 12:27:55'),(135,112,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2018-02-19 12:57:57','2018-02-19 12:57:57'),(136,113,151,22,'Beard','Beard wash',25.00,'30','2018-02-19 13:12:37','2018-02-19 13:12:37'),(137,114,151,32,'Massage','Leg massage',25.00,'10','2018-02-19 14:55:53','2018-02-19 14:55:53'),(138,114,151,22,'Beard','Beard wash',25.00,'30','2018-02-19 14:55:53','2018-02-19 14:55:53'),(139,114,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2018-02-19 14:55:53','2018-02-19 14:55:53'),(140,115,151,22,'Beard','Beard wash',25.00,'30','2018-02-19 15:09:35','2018-02-19 15:09:35'),(141,116,151,22,'Beard','Beard wash',25.00,'30','2018-02-19 15:47:43','2018-02-19 15:47:43'),(142,117,151,32,'Massage','Leg massage',25.00,'10','2018-02-19 16:06:03','2018-02-19 16:06:03'),(143,118,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-03-07 14:53:42','2018-03-07 14:53:42'),(144,118,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 14:53:42','2018-03-07 14:53:42'),(145,118,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-03-07 14:53:42','2018-03-07 14:53:42'),(146,119,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-03-07 14:57:38','2018-03-07 14:57:38'),(147,119,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 14:57:38','2018-03-07 14:57:38'),(148,119,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-03-07 14:57:38','2018-03-07 14:57:38'),(149,120,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-03-07 14:58:30','2018-03-07 14:58:30'),(150,120,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 14:58:30','2018-03-07 14:58:30'),(151,120,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-03-07 14:58:30','2018-03-07 14:58:30'),(152,121,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-03-07 14:58:40','2018-03-07 14:58:40'),(153,121,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 14:58:40','2018-03-07 14:58:40'),(154,121,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-03-07 14:58:40','2018-03-07 14:58:40'),(155,122,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-03-07 16:20:22','2018-03-07 16:20:22'),(156,122,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 16:20:22','2018-03-07 16:20:22'),(157,122,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-03-07 16:20:22','2018-03-07 16:20:22'),(158,122,168,21,'Hair styling2','Hair Massage Extreme',150.00,'200','2018-03-07 16:20:22','2018-03-07 16:20:22'),(159,122,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-03-07 16:20:22','2018-03-07 16:20:22'),(160,122,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-03-07 16:20:22','2018-03-07 16:20:22'),(161,123,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-03-07 16:21:01','2018-03-07 16:21:01'),(162,123,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 16:21:01','2018-03-07 16:21:01'),(163,123,168,20,'Hair styling2','Hair Massage Deluxe',200.00,'20','2018-03-07 16:21:01','2018-03-07 16:21:01'),(164,123,168,21,'Hair styling2','Hair Massage Extreme',150.00,'200','2018-03-07 16:21:01','2018-03-07 16:21:01'),(165,123,168,26,'Hair styling2','Hair Growth Spa',20.00,'25','2018-03-07 16:21:01','2018-03-07 16:21:01'),(166,123,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-03-07 16:21:01','2018-03-07 16:21:01'),(167,124,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-03-07 17:08:57','2018-03-07 17:08:57'),(168,124,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-03-07 17:08:57','2018-03-07 17:08:57'),(169,124,168,19,'Hair styling2','Hair Spa Deluxe Double',200.00,'80','2018-03-07 17:08:57','2018-03-07 17:08:57'),(170,124,168,23,'Eye lash','Eye Massage',100.00,'30','2018-03-07 17:08:57','2018-03-07 17:08:57'),(171,124,168,38,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',45.00,'20','2018-03-07 17:08:57','2018-03-07 17:08:57'),(172,125,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-03-09 14:10:58','2018-03-09 14:10:58'),(173,125,168,18,'Hair styling2','Hair Spa Extreme',200.00,'100','2018-03-09 14:10:58','2018-03-09 14:10:58'),(174,125,168,23,'Eye lash','Eye Massage',100.00,'30','2018-03-09 14:10:58','2018-03-09 14:10:58'),(175,126,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-03-09 14:50:24','2018-03-09 14:50:24'),(176,127,168,17,'Hair styling2','Hair Spa Deluxe',200.00,'100','2018-03-21 00:18:39','2018-03-21 00:18:39'),(177,128,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2018-03-21 00:33:25','2018-03-21 00:33:25'),(178,129,151,2,'Eye lash','Eye Make Up (Cerylon/Mac) For Women',700.00,'50','2018-03-21 00:35:38','2018-03-21 00:35:38'),(179,130,151,22,'Beard','Beard wash',25.00,'30','2018-03-21 00:38:30','2018-03-21 00:38:30');
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salon_id` int(11) NOT NULL DEFAULT '0',
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paypal_email` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_item_count` int(11) DEFAULT NULL,
  `booking_date` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_time` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_time` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_status` varchar(355) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `cancelled_by` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refund_status` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` decimal(8,2) unsigned DEFAULT NULL,
  `paypal_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `paypal_transaction_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `payment_status` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paypal_price` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `pending_price` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `salon_id`, `uid`, `first_name`, `last_name`, `email`, `paypal_email`, `phone`, `order_item_count`, `booking_date`, `start_time`, `end_time`, `service_status`, `cancelled_by`, `refund_status`, `total`, `paypal_status`, `paypal_transaction_id`, `payment_status`, `paypal_price`, `pending_price`, `status`, `ip_address`, `created`, `modified`) VALUES (1,151,'0','Rahul','Sharma','rahulsharma@avainfotech.com',NULL,'6666633333',2,'13-06-2017','11:00 am','01:45 pm','pending',NULL,NULL,1220.00,'VERIFIED','37243705RJ6817733','Pending','10.00','1,210.00','1','122.173.196.147','2017-06-09 22:31:58','2017-06-09 22:31:58'),(2,168,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',3,'10-06-2017','10:00 am','03:00 pm','completed',NULL,NULL,550.00,'VERIFIED','84D355568D8897831','Pending','15.00','535.00','1','122.173.196.147','2017-06-09 22:32:39','2017-06-09 22:32:39'),(3,168,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',2,'09-06-2017','12:00 pm','04:30 pm','completed',NULL,NULL,450.00,'VERIFIED','5BN39058DP515174U','Pending','10.00','440.00','1','122.173.196.147','2017-06-09 22:36:58','2017-06-09 22:36:58'),(4,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',1,'18-06-2017','09:15 am','09:45 am','completed',NULL,NULL,25.00,'VERIFIED','3N9783765Y2446315','Pending','5.00','20.00','1','122.173.196.147','2017-06-09 22:42:44','2017-06-09 22:42:44'),(5,151,'151','gurpreet','singh','gurpreet@futureworktechnologies.com',NULL,'1234567896',1,'09-06-2017','12:15 pm','01:30 pm','pending',NULL,NULL,1200.00,'VERIFIED','8BF942665A648453D','Pending','5.00','1,195.00','1','122.160.12.89','2017-06-09 22:59:35','2017-06-09 22:59:35'),(6,151,'0','Diksha','Khajuria','diksha@avainfotech.com',NULL,'564654564564',1,'09-06-2017','09:15 am','09:45 am','pending',NULL,NULL,25.00,'VERIFIED','4X1979104T237590T','Pending','5.00','20.00','1','122.173.196.147','2017-06-10 01:10:10','2017-06-10 01:10:10'),(7,168,'0','Test','test','test@gmail.com',NULL,'123456',3,'21-06-2017','12:00 pm','05:00 pm','completed',NULL,NULL,550.00,'VERIFIED','5B073821JT710342U','Pending','15.00','535.00','1','122.160.12.89','2017-06-10 23:01:19','2017-06-10 23:01:19'),(8,168,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'13-06-2017','11:45 am','04:15 pm','completed',NULL,NULL,450.00,'VERIFIED','9RG32355YA979670S','Pending','10.00','440.00','1','122.160.12.89','2017-06-13 21:58:52','2017-06-13 21:58:52'),(9,168,'0','Priyank','lohan','priyank@futureworktechnologies.com',NULL,'9999955555',1,'14-06-2017','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.9.146','2017-06-14 22:08:00','2017-06-14 22:08:00'),(10,168,'0','Priyank','lohan','priyank@futureworktechnologies.com',NULL,'9999955555',1,'14-06-2017','03:00 pm','04:45 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.9.146','2017-06-14 22:24:54','2017-06-14 22:24:54'),(11,168,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'14-06-2017','10:15 am','12:00 pm','completed',NULL,NULL,200.00,'VERIFIED','0ML93054VB017060U','Pending','5.00','195.00','1','122.173.9.146','2017-06-14 22:41:17','2017-06-14 22:41:17'),(13,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'20-06-2017','04:45 pm','05:15 pm','pending',NULL,NULL,25.00,'VERIFIED','10G47528HT3343355','Pending','5.00','20.00','1','122.173.9.146','2017-06-15 20:15:20','2017-06-15 20:15:20'),(14,168,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'17-06-2017','02:00 pm','05:30 pm','completed',NULL,NULL,400.00,'VERIFIED','0AE36111L8992524E','Pending','10.00','390.00','1','122.173.9.146','2017-06-15 22:57:23','2017-06-15 22:57:23'),(15,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'16-06-2017','11:00 am','01:45 pm','pending',NULL,NULL,1220.00,'VERIFIED','86579651JA585473K','Pending','10.00','1,210.00','1','122.173.9.146','2017-06-16 01:45:35','2017-06-16 01:45:35'),(16,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'20-06-2017','10:45 am','12:15 pm','pending',NULL,NULL,20.00,'VERIFIED','0GA31018CG385794X','Pending','5.00','15.00','1','122.173.249.166','2017-06-16 18:24:29','2017-06-16 18:24:29'),(17,168,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',4,'16-06-2017','12:15 pm','05:15 pm','completed',NULL,NULL,800.00,'VERIFIED','3RY65057HE5208058','Pending','20.00','780.00','1','122.173.22.40','2017-06-16 20:41:49','2017-06-16 20:41:49'),(18,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'16-06-2017','02:00 pm','04:45 pm','pending',NULL,NULL,1220.00,'0','0',NULL,'10.00','1,210.00',NULL,'122.173.22.40','2017-06-16 20:59:18','2017-06-16 20:59:18'),(19,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'16-06-2017','02:00 pm','04:45 pm','pending',NULL,NULL,1220.00,'VERIFIED','8XT33930LK314154L','Pending','10.00','1,210.00','1','122.173.22.40','2017-06-16 21:01:21','2017-06-16 21:01:21'),(20,168,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',3,'17-06-2017','01:45 pm','06:30 pm','completed',NULL,NULL,600.00,'VERIFIED','0YX03496550242251','Pending','15.00','585.00','1','122.173.22.40','2017-06-16 22:27:29','2017-06-16 22:27:29'),(22,168,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',2,'27-06-2017','01:15 pm','05:45 pm','pending',NULL,NULL,450.00,'0','0',NULL,'10.00','440.00','1','122.173.63.38','2017-06-20 02:03:03','2017-06-20 02:03:03'),(24,151,'151','gurpreet','singh','gurpreet@futureworktechnologies.com',NULL,'1234567896',1,'03-07-2017','10:45 am','12:00 pm','pending',NULL,NULL,1200.00,'0','0',NULL,'5.00','1,195.00','1','122.173.194.220','2017-06-20 17:55:58','2017-06-20 17:55:58'),(25,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'23-06-2017','09:00 am','11:45 am','pending',NULL,NULL,1220.00,'0','0',NULL,'10.00','1,210.00','1','110.225.214.67','2017-06-21 18:37:37','2017-06-21 18:37:37'),(26,168,'166','gurpreet','singh','gurpreet@test2.com',NULL,'9999999999',1,'22-06-2017','04:30 pm','06:00 pm','completed',NULL,NULL,150.00,'0','0',NULL,'5.00','145.00','1','110.225.214.67','2017-06-21 19:40:21','2017-06-21 19:40:21'),(27,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'123456789',2,'04-07-2017','09:30 am','12:15 pm','cancelled',NULL,NULL,1220.00,'0','0',NULL,'10.00','1,210.00','1','122.173.157.126','2017-06-22 00:26:53','2017-06-22 00:26:53'),(28,168,'0','phoebe','white','pebe5@me.com',NULL,'07914728970',1,'21-06-2017','11:45 am','01:15 pm','completed',NULL,NULL,150.00,'0','0',NULL,'5.00','145.00',NULL,'86.189.207.203','2017-06-22 05:08:20','2017-06-22 05:08:20'),(29,168,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'30-06-2017','06:00 pm','06:30 pm','cancelled',NULL,NULL,20.00,'0','0',NULL,'5.00','15.00','1','122.173.40.138','2017-06-23 00:24:18','2017-06-23 00:24:18'),(31,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'24-06-2017','09:00 am','10:00 am','completed',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.174.182','2017-06-23 16:20:11','2017-06-23 16:20:11'),(32,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'24-06-2017','09:00 am','10:00 am','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.174.182','2017-06-23 16:20:30','2017-06-23 16:20:30'),(33,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'24-06-2017','10:00 am','11:00 am','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.174.182','2017-06-23 17:59:21','2017-06-23 17:59:21'),(34,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'27-06-2017','01:00 pm','02:00 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.75.243','2017-06-24 17:32:03','2017-06-24 17:32:03'),(35,151,'155','gurpreet','singh','gurpreet@futureworktechnologies.co',NULL,'9999999999',1,'28-06-2017','12:45 pm','01:45 pm','cancelled',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.175.4','2017-06-27 17:27:35','2017-06-27 17:27:35'),(36,151,'0','Rahul','Sharma','rahulsharma@avainfotech.com',NULL,'897546655685',1,'28-06-2017','01:45 pm','02:15 pm','completed',NULL,NULL,25.00,'0','0',NULL,'5.00','20.00',NULL,'122.173.175.4','2017-06-27 22:19:22','2017-06-27 22:19:22'),(37,168,'194','Neha','Khanna','neha@avainfotech.com',NULL,NULL,3,'05-07-2017','10:00 am','02:45 pm','cancelled',NULL,NULL,600.00,'0','0',NULL,'15.00','585.00',NULL,'122.173.153.195','2017-06-29 01:12:38','2017-06-29 01:12:38'),(38,151,'0','Anurag','Sharma','anurag@avainfotech.com',NULL,'5364544531453',1,'04-07-2017','11:30 am','12:30 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.156.183','2017-07-05 02:57:46','2017-07-05 02:57:46'),(39,151,'0','Anurag','Sharma','anurag@avainfotech.com',NULL,'5364544531453',1,'04-07-2017','11:30 am','12:30 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.156.183','2017-07-05 02:58:10','2017-07-05 02:58:10'),(40,151,'0','Anurag','Sharma','anurag@avainfotech.com',NULL,'5364544531453',1,'04-07-2017','11:30 am','12:30 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.156.183','2017-07-05 02:58:19','2017-07-05 02:58:19'),(41,151,'0','Anurag','Sharma','anurag@avainfotech.com',NULL,'5364544531453',1,'04-07-2017','11:30 am','12:30 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.156.183','2017-07-05 02:58:37','2017-07-05 02:58:37'),(42,151,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'02-09-2017','10:15 am','10:45 am','pending',NULL,NULL,25.00,'0','0',NULL,'5.00','20.00','1','122.173.153.230','2017-09-01 18:32:01','2017-09-01 18:32:01'),(43,168,'0','Diksha','Khajuria','diksha@avainfotech.com',NULL,'9780099887',1,'07-09-2017','10:00 am','11:45 am','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.201.11','2017-09-09 00:31:52','2017-09-09 00:31:52'),(44,168,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'21-09-2017','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.201.11','2017-09-09 00:47:15','2017-09-09 00:47:15'),(45,168,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'21-09-2017','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.201.11','2017-09-09 00:55:17','2017-09-09 00:55:17'),(46,168,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'21-09-2017','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.201.11','2017-09-09 00:56:51','2017-09-09 00:56:51'),(47,168,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'21-09-2017','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.201.11','2017-09-09 00:56:57','2017-09-09 00:56:57'),(48,168,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'21-09-2017','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.201.11','2017-09-09 01:08:05','2017-09-09 01:08:05'),(49,168,'0','Diksha','Khajuria','diksha@avainfotech.com',NULL,'123456',1,'13-09-2017','10:00 am','11:45 am','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.5.40','2017-09-13 19:55:54','2017-09-13 19:55:54'),(50,151,'0','Parveen','Kumar','parveen@avainfotech.com',NULL,'6666699999',1,'14-09-2017','02:00 pm','03:00 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.5.40','2017-09-14 20:45:27','2017-09-14 20:45:27'),(51,151,'0','Parveen','Kumar','parveen@avainfotech.com',NULL,'6666699999',1,'14-09-2017','02:00 pm','03:00 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.5.40','2017-09-14 20:45:53','2017-09-14 20:45:53'),(52,151,'0','Parveen','Kumar','parveen@avainfotech.com',NULL,'6666699999',1,'14-09-2017','02:00 pm','03:00 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.5.40','2017-09-14 20:45:57','2017-09-14 20:45:57'),(53,151,'0','Parveen','Kumar','parveen@avainfotech.com',NULL,'6666699999',1,'14-09-2017','02:00 pm','03:00 pm','pending',NULL,NULL,700.00,'0','0',NULL,'5.00','695.00',NULL,'122.173.5.40','2017-09-14 20:45:58','2017-09-14 20:45:58'),(54,151,'0','Parveen','Kumar','parveen@avainfotech.com',NULL,'6666699999',1,'14-09-2017','02:00 pm','03:00 pm','pending',NULL,NULL,700.00,'VERIFIED','6MT90054EG4533401','Pending','5.00','695.00','1','122.173.5.40','2017-09-14 20:49:02','2017-09-14 20:49:02'),(55,151,'0','Parveen','Kumar','parveen@avainfotech.com',NULL,'1234567890',1,'27-09-2017','03:15 pm','03:45 pm','pending',NULL,NULL,25.00,'VERIFIED','9XD52253P0068664C','Pending','5.00','20.00','1','122.160.12.89','2017-09-27 19:45:44','2017-09-27 19:45:44'),(56,151,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'1032132131',1,'28-09-2017','02:00 pm','02:15 pm','pending',NULL,NULL,24.00,'0','0',NULL,'5.00','19.00',NULL,'122.173.53.237','2017-09-29 00:03:53','2017-09-29 00:03:53'),(57,151,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'1032132131',1,'28-09-2017','02:00 pm','02:15 pm','pending',NULL,NULL,24.00,'VERIFIED','5C764268MY8696431','Pending','5.00','19.00','1','122.173.53.237','2017-09-29 00:04:20','2017-09-29 00:04:20'),(58,151,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'345235232',1,'28-09-2017','05:00 pm','05:30 pm','pending',NULL,NULL,25.00,'VERIFIED','8G0827909J049160B','Pending','5.00','20.00','1','122.173.53.237','2017-09-29 00:23:27','2017-09-29 00:23:27'),(59,151,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'5436436436',1,'30-09-2017','04:15 pm','04:30 pm','cancelled',NULL,NULL,25.00,'VERIFIED','00229832UG807092E','Pending','5.00','20.00','1','122.160.12.89','2017-09-29 18:09:23','2017-09-29 18:09:23'),(60,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'9815635478',1,'11-10-2017','03:00 pm','04:45 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.160.12.89','2017-10-07 19:13:19','2017-10-07 19:13:19'),(61,168,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'20-12-2017','04:30 pm','06:15 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'86.171.29.255','2017-10-17 03:09:53','2017-10-17 03:09:53'),(62,201,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'9999999999',1,'10-11-2017','11:00 am','11:45 am','pending',NULL,NULL,25.00,'0','0',NULL,'5.00','20.00',NULL,'122.173.154.122','2017-11-06 20:16:17','2017-11-06 20:16:17'),(63,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'05-12-2017','09:00 am','10:00 am','pending',NULL,NULL,700.00,'VERIFIED','9BT90297H3213225M','Pending','5.00','695.00','1','122.173.198.181','2017-12-05 21:24:14','2017-12-05 21:24:14'),(64,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'06-12-2017','05:00 pm','05:30 pm','cancelled',NULL,NULL,25.00,'VERIFIED','2RC65415MA904142A','Pending','5.00','20.00','1','122.173.198.181','2017-12-05 21:26:30','2017-12-05 21:26:30'),(65,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'07-12-2017','11:00 am','11:15 am','cancelled','customer',NULL,25.00,'VERIFIED','5W001963XC6760701','Pending','5.00','20.00','1','122.173.198.181','2017-12-07 00:35:31','2017-12-06 00:35:31'),(66,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'11-12-2017','12:30 pm','01:00 pm','pending',NULL,NULL,25.00,'VERIFIED','2V824662P35380610','Pending','5.00','20.00','1','122.173.198.181','2017-12-06 19:03:36','2017-12-06 19:03:36'),(67,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'9999999999',1,'16-01-2018','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.173.210.93','2018-01-16 09:39:18','2018-01-16 09:39:18'),(68,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'9999999999',1,'16-01-2018','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'VERIFIED','0FK43408XL5956039','Pending','5.00','195.00','1','122.173.210.93','2018-01-16 09:40:18','2018-01-16 09:40:18'),(69,168,'0','Gurpreet','singh','gurpreet@avainfotech.com','dsfsddsg@fsdg.com','9999999999',1,'19-01-2018','02:45 pm','03:15 pm','cancelled','customer','completed',20.00,'VERIFIED','2005164149700240T','Pending','5.00','15.00','1','122.173.210.93','2018-01-16 10:58:33','2018-01-16 10:58:33'),(70,168,'43','netin','Sharmaa','netin@avainfotech.com','simerjit@avainfotech.com','123456789',1,'24-01-2018','01:00 pm','02:45 pm','cancelled','customer','completed',200.00,'VERIFIED','6BR98803BE417253U','Pending','5.00','195.00','1','122.160.12.89','2018-01-18 07:02:29','2018-01-18 07:02:29'),(71,168,'0','Diksha','Khajuria','dikukhajuria207@gmail.com',NULL,'12354875412',1,'25-01-2018','10:15 am','10:45 am','pending',NULL,NULL,100.00,'VERIFIED','0LR208828Y295972B','Pending','5.00','95.00','1','122.160.12.89','2018-01-18 07:41:02','2018-01-18 07:41:02'),(72,168,'0','Ramit','Vahara','ramit@avainfotech.com',NULL,'789654132',1,'25-01-2018','12:15 pm','01:45 pm','pending',NULL,NULL,200.00,'VERIFIED','7U989445PK691292S','Pending','5.00','195.00','1','122.160.12.89','2018-01-18 07:49:29','2018-01-18 07:49:29'),(73,168,'0','Rahul','Sharma','gurpreet@avainfotech.com',NULL,'42135325235',1,'25-01-2018','04:30 pm','05:00 pm','pending',NULL,NULL,20.00,'VERIFIED','23988989333956437','Pending','5.00','15.00','1','122.173.26.145','2018-01-18 11:00:07','2018-01-18 11:00:07'),(74,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'9999999999',1,'25-01-2018','02:45 pm','03:15 pm','pending',NULL,NULL,45.00,'VERIFIED','2M118390GP198045Y','Pending','5.00','40.00','1','171.61.210.161','2018-01-18 12:57:17','2018-01-18 12:57:17'),(75,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'25-01-2018','05:30 pm','06:00 pm','pending',NULL,NULL,45.00,'VERIFIED','5AR18935YF265623E','Pending','5.00','40.00','1','171.61.210.161','2018-01-18 13:11:57','2018-01-18 13:11:57'),(76,168,'151','gurpreet','singh','gurpreet@avainfotech.com','dsfsddsg@fsdg.com','1234567896',1,'25-01-2018','06:15 pm','06:45 pm','cancelled','customer',NULL,100.00,'VERIFIED','5KV9411986397590M','Pending','5.00','95.00','1','171.61.210.161','2018-01-18 13:14:20','2018-01-18 13:14:20'),(77,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'9999999999',1,'23-01-2018','07:00 pm','07:30 pm','pending',NULL,NULL,45.00,'VERIFIED','8V775569C5368382M','Pending','5.00','40.00','1','110.225.206.41','2018-01-19 07:00:43','2018-01-19 07:00:43'),(78,168,'43','netin','Sharmaa','netin@avainfotech.com',NULL,'123456789',1,'19-01-2018','04:15 pm','06:00 pm','pending',NULL,NULL,200.00,'VERIFIED','07922087PA281364K','Pending','5.00','195.00','1','122.160.12.89','2018-01-19 08:55:49','2018-01-19 08:55:49'),(79,168,'43','netin','Sharmaa','netin@avainfotech.com',NULL,'123456789',1,'19-01-2018','10:15 am','10:45 am','pending',NULL,NULL,100.00,'VERIFIED','6XT50572DA527064R','Pending','5.00','95.00','1','122.160.12.89','2018-01-19 09:35:44','2018-01-19 09:35:44'),(80,168,'43','netin','Sharmaa','netin@avainfotech.com',NULL,'123456789',1,'20-01-2018','11:30 am','01:00 pm','pending',NULL,NULL,200.00,'VERIFIED','0JF17442MB1440453','Pending','5.00','195.00','1','122.160.12.89','2018-01-19 10:02:10','2018-01-19 10:02:10'),(81,168,'0','Rubal','khajuria','rubal@avainfotech.com',NULL,'464382749082390',1,'22-01-2018','10:30 am','12:00 pm','pending',NULL,NULL,200.00,'VERIFIED','4XA31506W7784911A','Pending','5.00','195.00','1','122.160.12.89','2018-01-19 10:06:34','2018-01-19 10:06:34'),(82,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'5796464456',1,'29-01-2018','10:00 am','11:30 am','pending',NULL,NULL,200.00,'VERIFIED','7U003811PP2069422','Pending','5.00','195.00','1','110.225.206.41','2018-01-19 11:58:34','2018-01-19 11:58:34'),(83,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567899',1,'29-01-2018','11:45 am','12:15 pm','pending',NULL,NULL,20.00,'VERIFIED','0HN62989KF767122P','Pending','5.00','15.00','1','110.225.206.41','2018-01-19 12:02:30','2018-01-19 12:02:30'),(84,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567899',1,'29-01-2018','12:30 pm','01:00 pm','pending',NULL,NULL,20.00,'VERIFIED','14893432DJ9847616','Pending','5.00','15.00','1','110.225.206.41','2018-01-19 12:05:11','2018-01-19 12:05:11'),(85,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'7878979876',1,'29-01-2018','01:15 pm','01:45 pm','pending',NULL,NULL,200.00,'VERIFIED','57T66473MC2179218','Pending','5.00','195.00','1','110.225.206.41','2018-01-19 12:07:47','2018-01-19 12:07:47'),(86,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'29-01-2018','02:00 pm','02:30 pm','pending',NULL,NULL,200.00,'VERIFIED','6AM549187Y715112P','Pending','5.00','195.00','1','110.225.206.41','2018-01-19 12:11:24','2018-01-19 12:11:24'),(87,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'29-01-2018','02:45 pm','03:15 pm','pending',NULL,NULL,45.00,'VERIFIED','65H26955NB264582N','Pending','5.00','40.00','1','110.225.206.41','2018-01-19 12:22:00','2018-01-19 12:22:00'),(88,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'29-01-2018','03:30 pm','04:00 pm','pending',NULL,NULL,100.00,'VERIFIED','4KH04460VS695392B','Pending','5.00','95.00','1','110.225.206.41','2018-01-19 12:28:01','2018-01-19 12:28:01'),(89,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'29-01-2018','04:15 pm','04:45 pm','pending',NULL,NULL,200.00,'VERIFIED','4352143820532641V','Pending','5.00','195.00','1','110.225.206.41','2018-01-19 12:30:32','2018-01-19 12:30:32'),(90,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'29-01-2018','05:00 pm','05:30 pm','pending',NULL,NULL,200.00,'VERIFIED','32422092M2987524U','Pending','5.00','195.00','1','110.225.206.41','2018-01-19 12:33:49','2018-01-19 12:33:49'),(91,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'31-01-2018','10:00 am','10:30 am','cancelled','therapist',NULL,45.00,'VERIFIED','2T8062767W9888321','Pending','5.00','40.00','1','110.225.206.41','2018-01-19 12:43:18','2018-01-19 12:43:18'),(92,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'31-01-2018','11:00 am','11:30 am','cancelled','therapist',NULL,20.00,'VERIFIED','40244940RA636152P','Pending','5.00','15.00','1','110.225.206.41','2018-01-19 12:46:54','2018-01-19 12:46:54'),(93,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'30-01-2018','11:45 am','12:15 pm','pending',NULL,NULL,45.00,'VERIFIED','0XG7123149818443A','Pending','5.00','40.00','1','110.225.206.41','2018-01-19 13:03:45','2018-01-19 13:03:45'),(94,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'30-01-2018','01:15 pm','01:45 pm','pending',NULL,NULL,45.00,'VERIFIED','1WA631384F389450B','Pending','5.00','40.00','1','110.225.206.41','2018-01-19 13:08:47','2018-01-19 13:08:47'),(95,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'19-01-2018','01:30 pm','02:00 pm','pending',NULL,NULL,20.00,'VERIFIED','00M29226L44290147','Pending','5.00','15.00','1','110.225.206.41','2018-01-19 13:20:14','2018-01-19 13:20:14'),(96,168,'0','Gurpreet','singh','gurpreet@avainfotech.com',NULL,'3435446354',1,'29-01-2018','05:45 pm','06:15 pm','pending',NULL,NULL,200.00,'VERIFIED','2H248580VY077720Y','Pending','5.00','195.00','1','110.225.206.41','2018-01-19 13:34:02','2018-01-19 13:34:02'),(97,168,'0','Gurpreet','singh','gurpreet@avainfotech.com','gurpreet@avainfotech.com','9999999999',1,'26-01-2018','10:00 am','10:30 am','cancelled','customer',NULL,100.00,'VERIFIED','1AB348178K551931P','Pending','5.00','95.00','1','122.173.150.241','2018-01-23 04:50:45','2018-01-23 04:50:45'),(98,168,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'23-01-2018','06:00 pm','06:30 pm','pending',NULL,NULL,20.00,'VERIFIED','2SG42737BW828733S','Pending','5.00','15.00','1','122.173.150.241','2018-01-23 05:01:07','2018-01-23 05:01:07'),(99,168,'201','Anshul','Mahajan','anshul@avainfotech.com',NULL,'9999999999',1,'24-01-2018','02:00 pm','03:45 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'122.160.12.89','2018-01-23 07:21:16','2018-01-23 07:21:16'),(100,168,'201','Anshul','Mahajan','anshul@avainfotech.com',NULL,'9999999999',1,'24-01-2018','02:00 pm','03:45 pm','cancelled','therapist',NULL,200.00,'VERIFIED','0RK54515PB736231N','Pending','5.00','195.00','1','122.160.12.89','2018-01-23 07:23:32','2018-01-23 07:23:32'),(101,168,'0','Ritika','Bhatnagar','ritika@avainfotech.com','simerjit@avainfotech.com','12345678',1,'26-01-2018','10:00 am','11:45 am','cancelled','customer',NULL,200.00,'VERIFIED','13E53597FP8154725','Pending','5.00','195.00','1','122.160.12.89','2018-01-23 07:39:19','2018-01-23 07:39:19'),(102,168,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',1,'25-01-2018','06:15 pm','08:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'86.189.206.254','2018-01-25 16:22:31','2018-01-25 16:22:31'),(103,168,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'01-02-2018','01:15 pm','03:00 pm','pending',NULL,NULL,200.00,'0','0',NULL,'5.00','195.00',NULL,'86.189.205.102','2018-02-01 14:24:51','2018-02-01 14:24:51'),(104,168,'0','phoebe','white','info@mytreatmenthub.com',NULL,'00000000000000',1,'01-02-2018','03:00 pm','04:45 pm','pending',NULL,NULL,200.00,'VERIFIED','4PV49794LA369801J','Pending','5.00','195.00','1','86.189.205.102','2018-02-01 14:26:58','2018-02-01 14:26:58'),(105,168,'0','phoebe','white','info@mytreatmenthub.com','info@mytreatmenthub.com','00000000000000',1,'07-02-2018','02:45 pm','04:30 pm','cancelled','customer',NULL,200.00,'VERIFIED','7B803911929414814','Pending','5.00','195.00','1','86.189.205.102','2018-02-01 14:36:41','2018-02-01 14:36:41'),(106,151,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'05-02-2018','05:00 pm','05:15 pm','pending',NULL,NULL,24.00,'0','0',NULL,'5.00','19.00',NULL,'86.189.205.102','2018-02-01 14:55:19','2018-02-01 14:55:19'),(107,151,'199','Neha','Khanna','neha@avainfotech.com',NULL,NULL,1,'05-02-2018','05:00 pm','05:15 pm','pending',NULL,NULL,24.00,'0','0',NULL,'5.00','19.00',NULL,'86.189.205.102','2018-02-01 14:55:33','2018-02-01 14:55:33'),(108,168,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',1,'02-02-2018','10:15 am','11:45 am','completed',NULL,NULL,200.00,'VERIFIED','1GG34947R3475072T','Pending','5.00','195.00','1','171.61.212.98','2018-02-02 07:39:21','2018-02-02 07:39:21'),(109,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'03-02-2018','10:30 am','11:30 am','pending',NULL,NULL,700.00,'VERIFIED','07739989XX559245J','Pending','5.00','695.00','1','171.61.212.98','2018-02-02 07:45:14','2018-02-02 07:45:14'),(110,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'08-02-2018','09:15 am','09:45 am','pending',NULL,NULL,25.00,'VERIFIED','06M531519V321335S','Pending','5.00','20.00','1','171.61.212.98','2018-02-02 07:54:26','2018-02-02 07:54:26'),(111,151,'151','gurpreet','singh','gurpreet@avainfotech.com',NULL,'1234567896',1,'22-02-2018','09:30 am','09:45 am','pending',NULL,NULL,25.00,'VERIFIED','4WP09022L7452373R','Pending','5.00','20.00','1','122.173.150.57','2018-02-19 06:57:55','2018-02-19 06:57:55'),(112,151,'212','vandana','thakur','kavita20@gmail.com',NULL,'00000000',1,'22-02-2018','11:00 am','12:00 pm','pending',NULL,NULL,700.00,'VERIFIED','6P248441CW518311N','Pending','5.00','695.00','1','122.173.150.57','2018-02-19 07:27:57','2018-02-19 07:27:57'),(113,151,'212','vandana','thakur','kavita20@gmail.com',NULL,'00000000',1,'27-02-2018','01:30 pm','02:00 pm','pending',NULL,NULL,25.00,'VERIFIED','5D491603K7203082U','Pending','5.00','20.00','1','122.173.150.57','2018-02-19 07:42:37','2018-02-19 07:42:37'),(114,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',3,'19-02-2018','01:45 pm','03:15 pm','pending',NULL,NULL,750.00,'VERIFIED','0RK91195CC376441H','Pending','15.00','735.00','1','122.173.150.57','2018-02-19 09:25:53','2018-02-19 09:25:53'),(115,151,'168','diksha','khajuria','diksha@avainfotech.com',NULL,'1234567894455',1,'22-02-2018','01:45 pm','02:15 pm','cancelled','customer',NULL,25.00,'VERIFIED','8H1343452H600583W','Pending','5.00','20.00','1','122.173.150.57','2018-02-19 09:39:35','2018-02-19 09:39:35'),(116,151,'222','vandana','thakur','uic.16mca8058@gmail.com',NULL,'32524523653',1,'19-02-2018','05:00 pm','05:30 pm','pending',NULL,NULL,25.00,'VERIFIED','41C11992EH385121V','Pending','5.00','20.00','1','122.173.150.57','2018-02-19 10:17:43','2018-02-19 10:17:43'),(117,151,'222','vandana','thakur','uic.16mca8058@gmail.com',NULL,'32524523653',1,'22-02-2018','03:15 pm','03:30 pm','pending',NULL,NULL,25.00,'VERIFIED','1NF68307FH165751P','Pending','5.00','20.00','1','122.173.150.57','2018-02-19 10:36:03','2018-02-19 10:36:03'),(118,168,'223','prateek999999999','sharma@@@@@@@','prateekrajpurohit24@gmail.com',NULL,'999999999999999999999999999',3,'15-03-2018','12:00 pm','03:30 pm','pending',NULL,NULL,600.00,'0','0',NULL,'15.00','585.00',NULL,'122.160.12.89','2018-03-07 09:23:42','2018-03-07 09:23:42'),(119,168,'223','prateek999999999','sharma@@@@@@@','prateekrajpurohit24@gmail.com',NULL,'999999999999999999999999999',3,'15-03-2018','12:00 pm','03:30 pm','pending',NULL,NULL,600.00,'0','0',NULL,'15.00','585.00',NULL,'122.160.12.89','2018-03-07 09:27:38','2018-03-07 09:27:38'),(120,168,'223','prateek999999999','sharma@@@@@@@','prateekrajpurohit24@gmail.com',NULL,'999999999999999999999999999',3,'15-03-2018','12:00 pm','03:30 pm','pending',NULL,NULL,600.00,'0','0',NULL,'15.00','585.00',NULL,'122.160.12.89','2018-03-07 09:28:30','2018-03-07 09:28:30'),(121,168,'223','prateek999999999','sharma@@@@@@@','prateekrajpurohit24@gmail.com',NULL,'999999999999999999999999999',3,'15-03-2018','12:00 pm','03:30 pm','cancelled','customer',NULL,600.00,'VERIFIED','6CP147880A883031A','Pending','15.00','585.00','1','122.160.12.89','2018-03-07 09:28:40','2018-03-07 09:28:40'),(122,168,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',6,'08-03-2018','11:45 am','07:15 pm','pending',NULL,NULL,815.00,'0','0',NULL,'30.00','785.00',NULL,'122.160.12.89','2018-03-07 10:50:22','2018-03-07 10:50:22'),(123,168,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',6,'08-03-2018','11:45 am','07:15 pm','pending',NULL,NULL,815.00,'VERIFIED','0PM73935JF819624H','Pending','30.00','785.00','1','122.160.12.89','2018-03-07 10:51:01','2018-03-07 10:51:01'),(124,168,'223','prateek999999999','sharma@@@@@@@','prateekrajpurohit24@gmail.com',NULL,'999999999999999999999999999',5,'15-03-2018','01:45 pm','07:15 pm','pending',NULL,NULL,745.00,'VERIFIED','2CX31872FP272444T','Pending','25.00','720.00','1','122.160.12.89','2018-03-07 11:38:57','2018-03-07 11:38:57'),(125,168,'0','prateek','sharma','prateek@avainfotech.com',NULL,'85560756988',3,'22-03-2018','01:30 pm','05:30 pm','pending',NULL,NULL,500.00,'VERIFIED','1JU86567XK651722N','Pending','15.00','485.00','1','171.61.216.12','2018-03-09 08:40:58','2018-03-09 08:40:58'),(126,168,'227','kaka','sho','dksharma05@gmail.com',NULL,NULL,1,'20-03-2018','01:45 pm','03:30 pm','cancelled','customer',NULL,200.00,'VERIFIED','25F11987F9079354N','Pending','5.00','195.00','1','171.61.216.12','2018-03-09 09:20:24','2018-03-09 09:20:24'),(127,168,'0','Phoebe','White','info@mytreatmenthub.com','simerjit@avainfotech.com','0739732724',1,'22-03-2018','10:00 am','11:45 am','cancelled','customer',NULL,200.00,'VERIFIED','02858777YJ250190M','Pending','5.00','195.00','1','86.190.21.156','2018-03-20 18:48:39','2018-03-20 18:48:39'),(128,151,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',1,'20-03-2018','07:00 am','08:00 am','pending',NULL,NULL,700.00,'VERIFIED','78172095KX6714938','Pending','5.00','695.00','1','86.190.21.156','2018-03-20 19:03:25','2018-03-20 19:03:25'),(129,151,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',1,'21-03-2018','09:00 am','10:00 am','cancelled','therapist',NULL,700.00,'VERIFIED','19A18667030462255','Pending','5.00','695.00','1','86.190.21.156','2018-03-20 19:05:38','2018-03-20 19:05:38'),(130,151,'43','Phoebe','','info@mytreatmenthub.com',NULL,'123456789',1,'21-03-2018','06:15 pm','06:45 pm','cancelled','therapist',NULL,25.00,'VERIFIED','4VH58085AN5873201','Pending','5.00','20.00','1','86.190.21.156','2018-03-20 19:08:30','2018-03-20 19:08:30');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `page` varchar(355) DEFAULT NULL,
  `name` varchar(355) DEFAULT NULL,
  `content` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` (`id`, `page`, `name`, `content`, `created`, `modified`) VALUES (1,'careers','Careers','<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>','0000-00-00 00:00:00','2017-04-10 01:29:58'),(2,'privacy','Privacy Policy','<p><strong style=\"margin: 0px; padding: 0px; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem Ipsum</strong><span style=\"font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span></p>','0000-00-00 00:00:00','2017-04-10 01:46:07'),(3,'terms','Terms of Service','<p><strong style=\"margin: 0px; padding: 0px; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem Ipsum</strong><span style=\"font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.&nbsp;</span></p>','2017-04-10 10:42:18','2017-04-10 02:19:17'),(4,'about','About us','<p><strong style=\"margin: 0px; padding: 0px; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem Ipsum</strong><span style=\"font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.&nbsp;</span></p>','2017-04-10 10:42:18','2017-04-10 02:19:09'),(5,'help','Help & Support','<p><strong style=\"margin: 0px; padding: 0px; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem Ipsum</strong><span style=\"font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.&nbsp;</span></p>','2017-04-10 10:42:18','2017-04-10 02:19:00');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parent_categories`
--

DROP TABLE IF EXISTS `parent_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parent_categories`
--

LOCK TABLES `parent_categories` WRITE;
/*!40000 ALTER TABLE `parent_categories` DISABLE KEYS */;
INSERT INTO `parent_categories` (`id`, `name`, `created`, `modified`) VALUES (1,'Wines','2017-04-21 18:14:21','2017-04-22 17:37:12'),(6,'dummy category','2017-04-21 20:06:57','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `parent_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `salon_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` (`id`, `order_id`, `salon_id`, `user_id`, `rating`, `created`, `modified`) VALUES (1,3,168,155,4,'2017-06-15 12:07:09','2018-03-07 17:40:42'),(2,12,168,155,5,'2017-06-15 16:22:35','2017-06-15 16:22:35'),(3,11,168,155,5,'2017-06-16 13:08:00','2017-06-16 13:08:00'),(4,17,168,155,4,'2017-06-16 15:24:02','2018-02-19 15:27:45'),(5,22,168,155,5,'2017-06-21 16:47:51','2017-06-27 14:03:28'),(11,14,168,168,5,'2018-02-19 15:13:56','2018-03-08 14:10:19');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(355) DEFAULT NULL,
  `price` decimal(15,2) NOT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` (`id`, `category_id`, `user_id`, `name`, `price`, `duration`, `status`, `created`, `modified`) VALUES (34,4,202,'Eye Make Up (Cerylon/Mac) For Women',30.00,100,1,'2017-10-23 19:03:24','2017-10-23 19:03:24'),(2,4,151,'Eye Make Up (Cerylon/Mac) For Women',700.00,50,1,'2017-05-16 12:00:34','2017-05-16 12:00:34'),(33,4,201,'Eye Make Up (Cerylon/Mac) For Women',25.00,40,1,'2017-10-23 18:58:20','2017-10-23 18:58:20'),(32,8,151,'Leg massage',25.00,10,1,'2017-09-14 16:07:57','2017-09-14 16:07:57'),(12,4,165,'Lashing',45.00,50,1,'2017-05-17 06:07:18','2017-05-17 06:07:18'),(11,2,165,'Root Touch Up (Inoa) For Women',700.00,20,1,'2017-05-17 06:05:03','2017-05-17 06:05:03'),(10,7,165,'Cutting',24.00,90,1,'2017-05-17 06:04:44','2017-05-17 06:04:44'),(9,7,165,'Coloring For Men',250.00,300,1,'2017-05-17 06:01:06','2017-05-17 06:01:06'),(31,8,176,'Deep tissue massage',80.00,50,1,'2017-08-07 21:52:47','2017-08-07 21:52:47'),(30,2,176,'Hair dye',50.00,60,1,'2017-08-07 21:52:18','2017-08-07 21:52:18'),(17,2,168,'Hair Spa Deluxe',200.00,100,1,'2017-05-29 13:23:08','2017-05-31 13:30:02'),(18,2,168,'Hair Spa Extreme',200.00,100,1,'2017-05-29 13:23:42','2017-05-31 13:29:28'),(19,2,168,'Hair Spa Deluxe Double',200.00,80,1,'2017-05-29 13:30:24','2017-05-29 13:30:24'),(20,2,168,'Hair Massage Deluxe',200.00,20,1,'2017-05-29 13:35:07','2017-05-29 13:36:15'),(21,2,168,'Hair Massage Extreme',150.00,200,1,'2017-05-29 13:50:33','2017-05-29 13:50:33'),(22,7,151,'Beard wash',25.00,30,1,'2017-05-30 05:20:10','2017-06-01 05:23:39'),(23,4,168,'Eye Massage',100.00,30,1,'2017-05-30 11:51:24','2017-05-31 13:29:48'),(24,4,151,'acc',24.00,15,1,'2017-05-31 05:44:17','2017-09-14 16:06:51'),(25,4,169,'Eye Massage',52.00,50,1,'2017-05-31 13:05:19','2017-05-31 13:06:17'),(26,2,168,'Hair Growth Spa',20.00,25,1,'2017-06-10 16:06:55','2017-06-10 16:06:55'),(27,8,193,'Aromatherapy Massage',25.00,30,1,'2017-06-21 19:18:41','2017-06-21 19:18:41'),(28,8,193,'Hot Stone Massage',30.00,30,1,'2017-06-21 19:23:49','2017-06-21 19:23:49'),(29,8,193,'Deep Tissue Massage',35.00,20,1,'2017-06-21 19:53:29','2017-06-21 19:53:29'),(35,4,195,'Eye Make Up (Cerylon/Mac) For Women',35.00,120,1,'2017-10-23 19:04:49','2017-10-23 19:04:49'),(36,4,171,'Eye Make Up (Cerylon/Mac) For Women	',40.00,20,1,'2017-10-23 19:05:48','2017-10-23 19:05:48'),(37,4,166,'Eye Make Up (Cerylon/Mac) For Women	',45.00,25,1,'2017-10-23 19:06:43','2017-10-23 19:06:43'),(38,4,168,'Eye Make Up (Cerylon/Mac) For Women',45.00,20,1,'2017-10-23 19:07:39','2017-10-24 10:59:10'),(39,4,168,'Eye lye',20.00,10,0,'2018-02-19 14:39:39','2018-02-19 14:40:44'),(40,2,222,'Simple style',10.00,25,1,'2018-02-19 15:42:22','2018-02-19 15:44:51'),(41,4,222,'Eye lye',5.00,15,1,'2018-02-19 15:42:55','2018-02-19 15:42:55'),(42,7,222,'Beard Wash',15.00,20,1,'2018-02-19 15:43:30','2018-02-19 15:43:30'),(43,8,222,'Arm massage',40.00,25,1,'2018-02-19 15:44:10','2018-02-19 15:44:10'),(44,7,224,'trimming',50.00,20,0,'2018-03-07 15:19:24','2018-03-13 10:40:13'),(45,8,224,'oil massage',100.00,60,1,'2018-03-07 15:22:45','2018-03-07 15:22:45'),(46,7,225,'shave',100.00,35,0,'2018-03-08 12:03:14','2018-03-09 12:13:48'),(47,8,225,'shave',-1.00,-5,1,'2018-03-08 12:10:52','2018-03-08 12:10:52'),(48,2,225,'@#@#@',0.00,-1,1,'2018-03-08 12:16:56','2018-03-08 12:18:16');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socials`
--

DROP TABLE IF EXISTS `socials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `socials` (
  `id` int(11) NOT NULL,
  `cxz` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socials`
--

LOCK TABLES `socials` WRITE;
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staticpages`
--

DROP TABLE IF EXISTS `staticpages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staticpages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `position` varchar(250) DEFAULT NULL,
  `title` varchar(250) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(250) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL,
  `show_main` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `category` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staticpages`
--

LOCK TABLES `staticpages` WRITE;
/*!40000 ALTER TABLE `staticpages` DISABLE KEYS */;
INSERT INTO `staticpages` (`id`, `user_id`, `position`, `title`, `slug`, `description`, `image`, `status`, `show_main`, `created`, `modified`, `category`) VALUES (19,0,'privacypolicy','Privacy Policy','','<div class=\"privacy_section\">\r\n<div class=\"container\">\r\n<div class=\"about_heading\">\r\n<h2>Privacy Policy</h2>\r\n</div>\r\n<div class=\"text_cover\">\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','2406164427privacy_ground.jpg',1,0,'2018-03-14 09:22:53','2018-03-14 09:23:02','0'),(51,0,'about','About MTH','about-us','<div class=\"about_section\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"about_heading\">\r\n<h2>About MTH</h2>\r\n<p>&nbsp;</p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">After working in the UK Spa industry for a number of years&nbsp;</span><span lang=\"EN-GB\"><span lang=\"EN-GB\">I wanted to create a website that would make the wellness experience more positive for both the&nbsp; customer and therapist by overcoming&nbsp;</span>two main problems.<br /></span></p>\r\n<p class=\"gmail-m_-6281295334104668740gmail-MsoListParagraphCxSpFirst\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">For the customer, when you first book into a Spa, you see whichever therapist they have available. You have no background information on this therapist and you have no idea what their level of expertise is.&nbsp;&nbsp;The whole experience is therefore rather impersonal and does not meet their needs.&nbsp;</span></p>\r\n<p class=\"gmail-m_-6281295334104668740gmail-MsoListParagraphCxSpLast\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">Therapists are normally paid on a commission basis, and often receive a small percentage of what the customer pays to the Spa for the treatment. They have no control over their schedule and often work long hours. Their client base is built through the Spa and when they leave they are not allowed to continue seeing these clients or have any further contact&nbsp;</span><span lang=\"EN-GB\"><span lang=\"EN-GB\">with them</span>. This deters therapists from leaving and often results in the therapist putting up with unreasonable working conditions.</span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">Our new website will help both customers and therapists overcome these issues. When booking treatments or classes people will be able to base their decisions on: location, rating, price and/or qualifications of thetherapist. My treatment hub displays all this information in a clear and concise manner to ensure you choose someone who will give you exactly what you want. We take &pound;5 deposit, which covers the therapist for any no shows, and the remaining balance is paid by you directly to the therapist after you have completed your treatment.&nbsp;&nbsp;The therapists remain self-employed and are able to choose their hours, which means that they are in total control of their own schedules.&nbsp;</span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">&nbsp;</span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">Our website provides a full range of&nbsp;</span><span lang=\"EN-GB\"><span lang=\"EN-GB\">therapists&nbsp;</span>services, from osteopathy, acupuncture, personal training, massage and beauty treatments to counselling.&nbsp;<br /></span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">&nbsp;</span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">All our therapists are vetted and fully qualified with full insurance.&nbsp;<br /></span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\">&nbsp;</span></p>\r\n<p class=\"MsoNormal\" style=\"font-family: SFNSText, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; text-align: justify;\"><span lang=\"EN-GB\"><span lang=\"EN-GB\">My treatment hub</span>&nbsp;offers an unrivalled service to make your wellness experience just that much better.</span></p>\r\n<p><span lang=\"EN-GB\">&nbsp;</span></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','2406163506about_ground-2.jpg',1,0,'2018-01-25 18:24:47','2018-01-25 18:24:56','0'),(52,0,'faq','FAQ','faq-s','<div class=\"privacy_section\">\r\n<div class=\"container\">\r\n<div class=\"about_heading\">\r\n<h2>FAQ</h2>\r\n</div>\r\n<div class=\"text_cover\">\r\n<div class=\"privacy_text\">\r\n<h2>Question 1. General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>Question 1. General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>Question 1. General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>Question 1. General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>Question 1. General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>Question 1. General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','2406164749fground.jpg',1,0,'2017-06-24 16:47:07','2017-06-24 16:47:49','0'),(53,0,'t&c','Terms and service','terms-of-service','<div class=\"privacy_section\">\r\n<div class=\"container\">\r\n<div class=\"about_heading\">\r\n<h2>Terms and Condition</h2>\r\n</div>\r\n<div class=\"text_cover\">\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n<div class=\"privacy_text\">\r\n<h2>General Information</h2>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','2406164531termsback.jpg',1,0,'2017-06-24 16:45:08','2017-06-24 16:45:31','0');
/*!40000 ALTER TABLE `staticpages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `styles`
--

DROP TABLE IF EXISTS `styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `styles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `styles`
--

LOCK TABLES `styles` WRITE;
/*!40000 ALTER TABLE `styles` DISABLE KEYS */;
INSERT INTO `styles` (`id`, `name`, `created`, `modified`) VALUES (3,'cuff','2017-02-11 03:58:43','2017-02-11 03:58:43'),(2,'bangle1','2017-02-11 03:46:49','2017-02-11 03:49:43'),(4,'wrap ','2017-02-11 03:59:01','2017-02-11 03:59:01');
/*!40000 ALTER TABLE `styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `subscribe_date` varchar(355) DEFAULT NULL,
  `expire_date` varchar(355) NOT NULL,
  `subscribe_amount` decimal(15,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=226 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` (`id`, `user_id`, `subscribe_date`, `expire_date`, `subscribe_amount`, `created`, `modified`) VALUES (168,168,'07-03-2018','07-04-2018',20.00,'2017-06-28 15:51:10','2018-03-07 14:43:25'),(151,151,'20-03-2018','20-04-2018',20.00,'2017-06-28 17:18:52','2018-03-21 00:30:43'),(193,193,'29-06-2017','29-08-2017',20.00,'2017-06-29 15:04:49','2017-06-29 15:04:49'),(166,166,'03-10-2017','03-12-2017',20.00,'2017-10-03 17:31:57','2017-10-03 17:31:57'),(171,171,'23-10-2017','23-12-2017',20.00,'2017-10-23 15:27:25','2017-10-23 15:27:25'),(195,195,'23-10-2017','23-12-2017',20.00,'2017-10-23 15:27:43','2017-10-23 15:27:43'),(201,201,'23-10-2017','23-12-2017',20.00,'2017-10-23 16:46:48','2017-10-23 16:46:48'),(202,202,'23-10-2017','23-12-2017',20.00,'2017-10-23 16:47:03','2017-10-23 16:47:03'),(165,165,'07-03-2018','07-04-2018',20.00,'2017-11-13 20:17:26','2018-03-07 14:45:51'),(222,222,'20-02-2018','20-04-2018',20.00,'2018-02-19 15:52:10','2018-02-19 15:52:10'),(225,225,'09-03-2018','09-05-2018',20.00,'2018-03-08 12:58:30','2018-03-08 12:58:30');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` (`id`, `name`, `created`, `modified`) VALUES (3,'petrified','2017-02-11 03:56:47','2017-02-11 03:56:47'),(4,'buddha','2017-02-11 03:56:59','2017-02-11 03:56:59'),(5,'saint','2017-02-11 03:59:57','2017-02-11 03:59:57');
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unavailabilities`
--

DROP TABLE IF EXISTS `unavailabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unavailabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(50) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `hourfrom` varchar(100) DEFAULT NULL,
  `hourto` varchar(100) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unavailabilities`
--

LOCK TABLES `unavailabilities` WRITE;
/*!40000 ALTER TABLE `unavailabilities` DISABLE KEYS */;
INSERT INTO `unavailabilities` (`id`, `userid`, `date`, `hourfrom`, `hourto`, `note`) VALUES (1,151,'19-06-2017','11:00 am','01:00 pm','Busy'),(2,151,'19-06-2017','04:00 pm','05:15 pm','meeting'),(3,151,'23-06-2017','04:00 pm','05:30 pm',NULL),(12,151,'12-06-2017','10:45 am','12:45 pm','meetingdfgetgfg'),(21,168,'16-06-2017','11:15 am','12:00 pm','Personal work'),(16,151,'14-06-2017','10:45 am','11:15 am','hello'),(17,168,'30-05-2017','03:45 pm','04:45 pm','gbgfbgb'),(18,151,'29-05-2017','10:45 am','11:00 am','y5yuy'),(19,168,'11-06-2017','08:00 am','08:30 am','Busy with family'),(20,168,'17-06-2017','10:00 am','01:30 pm','Busy with family'),(23,168,'14-06-2017','11:30 am','11:45 am','Personal Meeting'),(24,151,'11-06-2017','09:00 am','09:15 am','hdghdg'),(25,168,'17-06-2017','06:45 pm','08:00 pm','Meeting for work'),(29,168,'22-06-2017','01:30 pm','02:00 pm','Meeting'),(30,168,'22-06-2017','02:15 pm','02:30 pm','Meeting'),(31,168,'20-06-2017','12:00 pm','01:45 pm','phoebe'),(32,176,'07-08-2017','02:30 pm','04:45 pm','Ella treatment'),(33,151,'11-09-2017','12:15 pm','12:30 pm','Lunch'),(34,151,'05-09-2017','10:30 am','10:45 am','Lunch'),(36,168,'20-02-2018','03:00 pm','03:15 pm','Busy'),(39,168,'10-04-2018','03:15 pm','05:00 pm','\n');
/*!40000 ALTER TABLE `unavailabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `view_pages` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
INSERT INTO `userpermissions` (`id`, `user_id`, `view_pages`) VALUES (6,437,'a:4:{i:0;s:5:\"Areas\";i:1;s:6:\"Cities\";i:2;s:6:\"Dishes\";i:3;s:11:\"Restaurants\";}'),(5,421,'a:4:{i:0;s:5:\"Areas\";i:1;s:6:\"Dishes\";i:2;s:6:\"Orders\";i:3;s:11:\"Restaurants\";}'),(7,32,'a:1:{i:0;s:8:\"Alergies\";}'),(8,43,'a:1:{i:0;s:6:\"Cities\";}'),(9,438,'a:24:{i:0;s:8:\"Alergies\";i:1;s:5:\"Areas\";i:2;s:5:\"Carts\";i:3;s:6:\"Cities\";i:4;s:9:\"Countries\";i:5;s:14:\"DishCategories\";i:6;s:11:\"DishSubcats\";i:7;s:14:\"DishesComments\";i:8;s:6:\"Dishes\";i:9;s:8:\"Favrests\";i:10;s:13:\"MetaLocations\";i:11;s:10:\"Mysqldumps\";i:12;s:6:\"Offers\";i:13;s:10:\"OrderItems\";i:14;s:7:\"Picodes\";i:15;s:11:\"Productmods\";i:16;s:4:\"Shop\";i:17;s:6:\"States\";i:18;s:11:\"Staticpages\";i:19;s:4:\"Tags\";i:20;s:5:\"Taxes\";i:21;s:5:\"Tests\";i:22;s:5:\"Times\";i:23;s:14:\"Useraddressses\";}'),(10,218,'a:27:{i:0;s:14:\"Addrestaurants\";i:1;s:5:\"Areas\";i:2;s:5:\"Carts\";i:3;s:6:\"Cities\";i:4;s:9:\"Countries\";i:5;s:10:\"Dashboards\";i:6;s:14:\"DishCategories\";i:7;s:11:\"DishSubcats\";i:8;s:14:\"DishesComments\";i:9;s:6:\"Dishes\";i:10;s:8:\"Favrests\";i:11;s:13:\"MetaLocations\";i:12;s:10:\"Mysqldumps\";i:13;s:6:\"Offers\";i:14;s:10:\"OrderItems\";i:15;s:6:\"Orders\";i:16;s:11:\"Productmods\";i:17;s:8:\"Products\";i:18;s:7:\"Qrcodes\";i:19;s:11:\"Restaurants\";i:20;s:16:\"RestaurantsTypes\";i:21;s:4:\"Shop\";i:22;s:6:\"States\";i:23;s:5:\"Taxes\";i:24;s:5:\"Tests\";i:25;s:5:\"Times\";i:26;s:14:\"Useraddressses\";}'),(11,327,'a:28:{i:0;s:5:\"Areas\";i:1;s:5:\"Carts\";i:2;s:6:\"Cities\";i:3;s:9:\"Countries\";i:4;s:14:\"DishCategories\";i:5;s:11:\"DishSubcats\";i:6;s:14:\"DishesComments\";i:7;s:6:\"Dishes\";i:8;s:8:\"Favrests\";i:9;s:13:\"MetaLocations\";i:10;s:10:\"Mysqldumps\";i:11;s:6:\"Offers\";i:12;s:10:\"OrderItems\";i:13;s:6:\"Orders\";i:14;s:7:\"Picodes\";i:15;s:11:\"Productmods\";i:16;s:8:\"Products\";i:17;s:11:\"Restaurants\";i:18;s:16:\"RestaurantsTypes\";i:19;s:4:\"Shop\";i:20;s:7:\"Socials\";i:21;s:6:\"States\";i:22;s:11:\"Staticpages\";i:23;s:4:\"Tags\";i:24;s:5:\"Taxes\";i:25;s:5:\"Tests\";i:26;s:5:\"Times\";i:27;s:14:\"Useraddressses\";}'),(12,47,'a:25:{i:0;s:14:\"Addrestaurants\";i:1;s:8:\"Alergies\";i:2;s:5:\"Carts\";i:3;s:14:\"DishCategories\";i:4;s:11:\"DishSubcats\";i:5;s:14:\"DishesComments\";i:6;s:6:\"Dishes\";i:7;s:8:\"Favrests\";i:8;s:13:\"MetaLocations\";i:9;s:10:\"Mysqldumps\";i:10;s:10:\"OrderItems\";i:11;s:6:\"Orders\";i:12;s:7:\"Picodes\";i:13;s:11:\"Productmods\";i:14;s:8:\"Products\";i:15;s:11:\"Restaurants\";i:16;s:16:\"RestaurantsTypes\";i:17;s:4:\"Shop\";i:18;s:7:\"Socials\";i:19;s:11:\"Staticpages\";i:20;s:4:\"Tags\";i:21;s:5:\"Taxes\";i:22;s:5:\"Tests\";i:23;s:5:\"Times\";i:24;s:14:\"Useraddressses\";}'),(16,427,'N;'),(17,529,'a:1:{i:0;s:11:\"Restaurants\";}'),(21,887,'N;'),(22,888,'N;'),(23,909,'N;'),(24,903,'N;'),(25,818,'N;'),(26,814,'N;'),(27,825,'N;'),(28,942,'N;');
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `gender` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `tokenhash` text COLLATE utf8_unicode_ci,
  `fboo_ids` text COLLATE utf8_unicode_ci,
  `verification_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `session_id` text COLLATE utf8_unicode_ci,
  `oauth_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauth_provider` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauth_uid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauth_secret` text COLLATE utf8_unicode_ci,
  `locale` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` text COLLATE utf8_unicode_ci,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `designation` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paypl_email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `store_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monday_timing_from` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour monday from',
  `monday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour monday to',
  `tuesday_timing_from` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour tuesday from',
  `tuesday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour tuesday to',
  `wednesday_timing_from` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour wednesday from',
  `wednesday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour wednesday to',
  `thursday_timing_from` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour thursday from',
  `thursday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'working hour thursday to',
  `friday_timing_from` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Working hour friday from',
  `friday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Working hour friday to',
  `saturday_timing_from` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Working hour saturday from',
  `saturday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Working hour saturday to',
  `sunday_timing_from` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Working hour sunday from',
  `sunday_timing_to` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Working hour sunday to',
  `about` longtext COLLATE utf8_unicode_ci,
  `banner_img` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_img` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gallery_img` text COLLATE utf8_unicode_ci,
  `attachments` text COLLATE utf8_unicode_ci,
  `avg_rating` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `recommended` int(11) NOT NULL DEFAULT '0',
  `subscribe_date` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expire_date` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subscribe_amount` decimal(15,2) DEFAULT NULL,
  `subscription` int(11) NOT NULL DEFAULT '0',
  `subscription_status` varchar(355) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'expired',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `role`, `email`, `gender`, `first_name`, `last_name`, `birth`, `name`, `image`, `username`, `password`, `address`, `city`, `phone`, `state`, `country`, `zip`, `latitude`, `longitude`, `active`, `tokenhash`, `fboo_ids`, `verification_code`, `session_id`, `oauth_token`, `oauth_provider`, `oauth_uid`, `google_id`, `oauth_secret`, `locale`, `link`, `created`, `modified`, `designation`, `paypl_email`, `store_name`, `location`, `monday_timing_from`, `monday_timing_to`, `tuesday_timing_from`, `tuesday_timing_to`, `wednesday_timing_from`, `wednesday_timing_to`, `thursday_timing_from`, `thursday_timing_to`, `friday_timing_from`, `friday_timing_to`, `saturday_timing_from`, `saturday_timing_to`, `sunday_timing_from`, `sunday_timing_to`, `about`, `banner_img`, `icon_img`, `gallery_img`, `attachments`, `avg_rating`, `recommended`, `subscribe_date`, `expire_date`, `subscribe_amount`, `subscription`, `subscription_status`) VALUES (43,'admin','info@mytreatmenthub.com','female','Phoebe','','08/02/2017','Netin Sharma','153836enjoy.png','info@mytreatmenthub.com','bc8d7bc1dc2eec9a1ff872a87d919a1fcecd88c5','IT Park','Chandigarh','123456789','Chandigarh','India','160020','30.7213417','75.7812596',1,'08eb02808f84583973469d8443af897479f244b1413e8053c6b7bb0310378f40320ee808c8eba8dcbdf4f667edd003da9322972d549e78f7526c5a3edceebb97','','','','','','','','','','','2017-04-06 08:38:39','2018-03-08 15:59:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(151,'freelancer','gurpreet@avainfotech.com','male','gurpreet','singh','20/06/2017','Gurpreet Singh','1230046.jpg','gurpreet@avainfotech.com','bc8d7bc1dc2eec9a1ff872a87d919a1fcecd88c5','Lushington road',NULL,'1234567896',NULL,NULL,'SW9 7AW','51.4653589','-0.1143288',1,'99912a975ca7f760def37187701e2301913e9ef0347932225b9353d52759399ceab2b172162aea2b92eba7d53856ffbe2d120052374b04aef37a42693c477508',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-13 06:27:36','2018-03-21 00:39:10','Owner','gurpreet','futureworktechnologies','chandigarh','09:00 am','07:00 pm','07:00 am','06:00 pm','09:00 am','08:00 pm','09:00 am','11:00 pm',NULL,NULL,'10:00 am','09:15 pm','10:00 am','09:00 pm','                                  dffdffgggfhggjhguguygdgdsgsdg      dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg     dffdffgggfhggjhguguygdgdsgsdg','120740makeover.jpg','104838arrow.png','1144264.jpg,1144265.jpg,1144266.jpg,1144267.jpg',NULL,'0',1,'20-03-2018','20-04-2018',20.00,0,'expired'),(155,'customer','gurpreet@futureworktechnologies.co','male','gurpreet','singh','05/01/2017','Gurpreet Singh','093724facial.jpg','gurpreet@futureworktechnologies.co','ef763bea0b312597e088b4ecb36dc40c243c746b','test\r\ntest',NULL,'9999999999',NULL,NULL,'160020','30.7213417','76.7812596',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-13 06:32:58','2018-02-19 17:24:16',NULL,'frweffs',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(162,'customer','gurpreet@futureworktechnologies.coom',NULL,'gurpreet','singh',NULL,'Gurpreet Singh',NULL,'gurpreet@futureworktechnologies.coom','ef763bea0b312597e088b4ecb36dc40c243c746b',NULL,NULL,NULL,NULL,NULL,'160020','30.7213417','76.7812596',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-15 08:16:37','2017-05-15 08:16:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(165,'freelancer','gurpreet@test.com','male','nitin','sharma','05/09/2017','Nitin Sharma',NULL,'gurpreet@test.com','ef763bea0b312597e088b4ecb36dc40c243c746b','chandigarh',NULL,'999999999',NULL,NULL,'160020','30.7213417','76.7812596',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-17 05:48:15','2017-05-24 05:38:25','Owner','gurpreet@test.com','Lush looks','mohali','11:30 am','01:15 am','07:30 am','01:00 am','09:30 am','01:00 am','02:30 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am',' lorem ipsum','055426banner.jpg','055426s3.png','055426service1.jpg,055426service2.jpg,055426service3.jpg',NULL,'0',0,'07-03-2018','07-04-2018',20.00,0,'expired'),(166,'freelancer','gurpreet@test2.com','male','gurpreet','singh','05/16/2017','Gurpreet Singh',NULL,'gurpreet@test2.com','ef763bea0b312597e088b4ecb36dc40c243c746b','etgfedgeed',NULL,'9999999999',NULL,NULL,'W11 3HX','51.5095171','-0.1946334',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-17 09:34:33','2017-10-23 19:06:14','Owner','gurpreet@test2.com','Gurpreet test2','chandigarh','09:00 am','01:00 am','07:00 am','01:00 am','02:00 am','01:00 am','09:00 am','01:00 am',NULL,NULL,NULL,NULL,NULL,NULL,'  lorem ipsum','101514banner2.jpg','101514s3.png','101514service1.jpg,101514service2.jpg,101514service3.jpg',NULL,'0',0,'03-10-2017','03-12-2017',20.00,0,'expired'),(168,'freelancer','diksha@avainfotech.com','female','diksha','khajuria','19/05/2017','Diksha Khajuria','104707salman.jpg','diksha@avainfotech.com','c29b7d2294220a3de3c0f3d0d65ce1a75f554020','Plot number 10, Ten Downing Street, Newburry',NULL,'1234567894455',NULL,NULL,'SW11 1TT','51.4628691','-0.1700149',1,'9fbae2e9060c76ab34a04d3d0609571adab8bfda52b1c150066bf7b8b9d958ed8dbd51b919176b82fd2b3dd1bff8fcaefda5b7951ee160f862813071156995a8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-29 10:17:18','2018-04-07 20:39:48','Massage  Specialist','diksha@avainfotech.com','The Skin & Body Spa','chandigarh',NULL,NULL,'10:00 am','08:00 pm','01:00 am','01:00 am','10:00 am','08:00 pm','01:00 am','01:00 am',NULL,NULL,NULL,NULL,'                       The Skin & Body Spa provides a beautiful, relaxing retreat where you can come and let our spa professionals take care of you. The Skin & Body spa provides a pain-free, non-invasive treatment that uses advanced radio frequency technology to comfortably heat the deeper layer of your skin, which increases collagen production. This effectively reduces fine lines and deep wrinkles, firms sagging skin, and restores a more youthful, refreshed appearance.','1047072.jpg','143710Lighthouse.jpg','143710Hydrangeas.jpg',NULL,'3.5',0,'07-03-2018','07-04-2018',20.00,0,'expired'),(171,'freelancer','anurag@avainfotech.com','male','anurag','sharma','06/05/2017','Anurag Sharma',NULL,'anurag@avainfotech.com','c29b7d2294220a3de3c0f3d0d65ce1a75f554020','dggdf',NULL,'9999999999',NULL,NULL,'NW10 5NH','51.5323525','-0.2350519',1,'bd21996bc48712bce31115b67e51b92f56d1218902d73b4410e100ddde2a107a9884ef1a9ab6b75ce1f865d500a9fba63c7ba37caebea73da410d6fd98e54d19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-05-31 13:23:50','2017-10-23 19:05:13','Designation','rwsws@dgsjhd.com','test','test location','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am',' fdhgfdhf','155412Desert.jpg','155412Chrysanthemum.jpg','155412Penguins.jpg,155412Tulips.jpg',NULL,'0',0,'23-10-2017','23-12-2017',20.00,0,'expired'),(173,'freelancer','balwinder@futureworktechnologies.com',NULL,'komal','komal',NULL,'Komal Komal',NULL,'balwinder@futureworktechnologies.com','a6349cd6bc36bd3b7bbb8223c98de50d48bfff2c',NULL,NULL,NULL,NULL,NULL,'160020','30.7213417','76.7812596',1,'e90dda35126f3f9c91efd95f4948acb12a00769d5c04f10369863ca16c4d108aacaf667afd59f5b7c9f4bd3766b37ad02276458b4731c459fafe7bc33dc1cad2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-01 07:07:57','2017-06-01 08:17:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(174,'freelancer','navish@avainfotech.com',NULL,'Navish','Sharma',NULL,'Navish Sharma',NULL,'navish@avainfotech.com','c29b7d2294220a3de3c0f3d0d65ce1a75f554020',NULL,NULL,NULL,NULL,NULL,'160020','30.7213417','76.7812596',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-10 15:41:05','2017-06-10 15:41:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(176,'freelancer','pebe5@me.com',NULL,'Phoebe','White','','Phoebe White',NULL,'pebe5@me.com','705d7a33a2908e3948ac9b1706d629fdf5758101','833 Harrow Road\r\n',NULL,'',NULL,NULL,'NW10 5NH','30.7213417','76.7812596',1,'49b483fc86820991915f0b315a60497e9ea12a16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-13 15:12:26','2017-09-13 19:30:46','','','','London','10:00 am','06:00 pm','08:00 am','04:00 pm','10:00 am','06:00 pm','08:00 am','09:00 pm','05:00 am','07:00 pm','09:00 am','10:00 pm','08:00 am','10:00 pm','   NIKXNKNXPKNPNSINDP;KMNC[M;DLNBOUGXSUCMX BDFHK','215111Screen Shot 2017-08-07 at 17.20.18.png','215111photo.jpg',NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(195,'freelancer','ritika@avainfotech.com','female','Balwinder','KLau','11/10/1993','Balwinder KLau',NULL,'ritika@avainfotech.com','c29b7d2294220a3de3c0f3d0d65ce1a75f554020','chandigarh',NULL,'9999999999',NULL,NULL,'N4 3HB','51.5686538','-0.1086003',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-21 19:54:34','2017-10-23 19:04:15','Designer','abc@test.com','Ritika\'s','chandigarh','08:00 am','06:00 pm','08:00 am','06:00 pm',NULL,NULL,'08:00 am','03:00 pm',NULL,NULL,'10:00 am','11:00 pm','09:00 am','11:00 pm',' ','152323MassageBanner.jpg','152323Desert.jpg','152323MassageBanner.jpg','195436New features (1).docx','0',0,'23-10-2017','23-12-2017',20.00,0,'expired'),(197,'freelancer','phoebewhite.8@gmail.com',NULL,'Phoebe','Why',NULL,'Phoebe Why',NULL,'phoebewhite.8@gmail.com','705d7a33a2908e3948ac9b1706d629fdf5758101',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-07 21:45:25','2017-08-07 21:45:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(199,'customer','neha@avainfotech.com',NULL,'Neha','Khanna',NULL,'Neha Khanna',NULL,'neha@avainfotech.com','c29b7d2294220a3de3c0f3d0d65ce1a75f554020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-07 18:24:50','2018-02-01 20:25:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(200,'customer','ayushtyagi1714@gmail.com','male','Ayush','Tyagi','23','Ayush Tyagi',NULL,'ayushtyagi1714@gmail.com','5d371382bb75f1545a282ccceb4dfb0b3b38a6f3','l',NULL,'1',NULL,NULL,'a','48.3705449','10.89779',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-10-07 14:43:05','2017-10-07 14:52:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(201,'freelancer','anshul@avainfotech.com','female','Anshul','Mahajan','11/10/1993','Anshul Mahajan',NULL,'anshul@avainfotech.com','c29b7d2294220a3de3c0f3d0d65ce1a75f554020','Pathankot',NULL,'9999999999',NULL,NULL,'TW2 7BA','51.4551407','-0.3401387',1,'879f337ebaccb35339f44e5cb4e60b970626efce',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-10-23 16:08:03','2018-01-23 12:47:46','Tester','tester@tester.com','Anshul\'s Store','Pathankot','08:00 am','07:15 pm','07:45 am','11:30 pm',NULL,NULL,NULL,NULL,'07:30 am','07:15 pm','06:30 am','05:15 pm','11:00 am','06:30 pm',' ','161939MassageBanner.jpg','161939Tulips.jpg','161939MassageBanner.jpg',NULL,'0',0,'23-10-2017','23-12-2017',20.00,0,'expired'),(202,'freelancer','parveen@avainfotech.com','male','Parveen','Kumar','11/10/1993','Parveen Kumar',NULL,'parveen@avainfotech.com','ef763bea0b312597e088b4ecb36dc40c243c746b','chandigarh',NULL,'9999999999',NULL,NULL,'BA1 1LN','51.3811437','-2.3578928',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-10-23 16:21:40','2017-10-23 19:02:35','Designer','tester@tester.com','Parveen\'s Store','chandigarh','06:00 am','08:00 pm','08:00 pm','03:00 am','09:00 pm','07:00 am',NULL,NULL,'05:00 am','01:00 pm','06:00 am','02:00 pm','10:00 am','09:00 pm',' ','162506MassageBanner.jpg','162506Jellyfish.jpg','162506MassageBanner.jpg',NULL,'0',0,'23-10-2017','23-12-2017',20.00,0,'expired'),(221,'customer','gurpreet@avainfotechi.com',NULL,'Gurpreet','singh',NULL,'Gurpreet Singh',NULL,'gurpreet@avainfotechi.com','ef763bea0b312597e088b4ecb36dc40c243c746b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-02-19 14:54:45','2018-02-19 14:54:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired'),(222,'freelancer','uic.16mca8058@gmail.com','female','vandana','thakur','05/02/2018','Vandana Thakur','1540553ZbzmjbQNyX9Sxau.jpg','uic.16mca8058@gmail.com','d9a3931e4ba379c4447ba07cbae4527d961b20d3','324,newyork',NULL,'32524523653',NULL,NULL,'7435657',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-02-19 15:32:38','2018-02-19 16:13:44','Manager','abc@gmail.com','Curadile','newyork','01:00 am','01:00 am',NULL,NULL,'01:00 am','01:00 am',NULL,NULL,'01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','01:00 am','  ','154055default-2.jpg','1540555rmQKAcYQWhzWePM.jpg','1613443ZbzmjbQNyX9Sxau.jpg','153252Koala.jpg','0',1,'20-02-2018','20-04-2018',20.00,0,'expired'),(224,'freelancer','prateek@avainfotech.com','male','prateek','purohit','04/17/2020','Prateek Purohit','132944icon (1).psd','prateek@avainfotech.com','8bca5b2a8e5e60e07ae436ad2b62b47770237eac','sector 58',NULL,'99999999999999999',NULL,NULL,'7878787878787',NULL,NULL,1,'405aff3a5afdb3c0accf1b0e7330e3883fff2368',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-03-07 15:13:53','2018-03-14 14:13:02','o23434@','hgyhft7y86747','krk5858585@@@@@@@','india','11:00 am','09:45 pm','11:00 am','01:45 am','11:00 am','09:45 pm','11:00 am','09:45 pm','11:00 am','09:45 pm','11:00 am','09:45 pm','01:00 am','01:00 am','   ',NULL,NULL,NULL,'151356DLY1KETUIAAFqZm.jpg','0',1,NULL,NULL,NULL,0,'expired'),(225,'freelancer','sharmaprateek24@gmail.com','male','ram','lal','11/05/2018','Ram Lal','114342278498.jpg','sharmaprateek24@gmail.com','ef763bea0b312597e088b4ecb36dc40c243c746b','---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------',NULL,'-8',NULL,NULL,'23232@#@#@#@#@#@#','37.5606725','-77.4457962',1,'51c783bbaa1032410eae896dd0ca099e7803d537e06c653d405be172a838afee9d20ef229c63bd58d43ed8701ec59980c471d7bef6f7d599a8406833d40ef175',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-03-08 10:37:32','2018-03-09 12:26:46','manager','fffffffffffffffffffffff','ererr','////////////////////////////////////////////////',NULL,NULL,'10:00 am','10:00 am','10:00 am','10:00 am','10:00 am','10:00 am','10:00 am','10:00 am',NULL,NULL,NULL,NULL,'   ','114342278498.jpg','114342Chrysanthemum.jpg','173338Penguins.jpg','103739DLY1KETUIAAFqZm.jpg','0',1,'09-03-2018','09-05-2018',20.00,1,'subscribed'),(226,'customer','suisha28@gmail.com',NULL,'kirk','shy',NULL,'Kirk Shy',NULL,'suisha28@gmail.com','e4eb7aecda2da0cf73aad6a7fff51906d728719d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'5061d4c9e603856be6db33a5769a55a4d0612695f5a041716bcef24f5b773cf2aa1f8c2f2b789b2da105f6a640afc7497bf67a260ea27169386e6a79ba1009c7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-03-08 12:39:49','2018-03-09 12:41:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',1,NULL,NULL,NULL,0,'expired'),(227,'customer','dksharma05@gmail.com',NULL,'kaka','sho',NULL,'Kaka Sho',NULL,'dksharma05@gmail.com','c5ffdfc62f433575252178c14fef2affb988163a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-03-09 14:36:11','2018-03-09 14:36:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,0,'expired');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'singhgur_spa'
--

--
-- Dumping routines for database 'singhgur_spa'
--
/*!50003 DROP FUNCTION IF EXISTS `get_distance_in_miles_between_geo_locations` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`singhgurpreet`@`localhost` FUNCTION `get_distance_in_miles_between_geo_locations`(`geo1_latitude` DECIMAL(10,6), `geo1_longitude` DECIMAL(10,6), `geo2_latitude` DECIMAL(10,6), `geo2_longitude` DECIMAL(10,6)) RETURNS decimal(10,3)
BEGIN
return ((ACOS(SIN(geo1_latitude * PI() / 180) * SIN(geo2_latitude * PI() / 180) + COS(geo1_latitude * PI() / 180) * COS(geo2_latitude * PI() / 180) * COS((geo1_longitude - geo2_longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-21  0:15:08
